from .client import AgentWatchClient
from .models import LogStage, LogEntry
from .auth import OAuth2Client, FixedTokenClient, MixedAuthClient, NoAuthClient, create_auth_client
from .fastmcp_decorator import (
    AgentWatchMCPDecorator,
    create_agent_watch_mcp_decorator,
    setup_global_decorator,
    logged_tool
)
from .decorator import (
    AgentWatchDecorator,
    create_agent_watch_decorator,
    setup_global_decorator as setup_standalone_decorator,
    get_global_decorator,
    receive_func,
    send_func,
    set_context,
    get_context
)
from .fastmcp_client import AgentWatchFastMCPClient, Client

__version__ = "1.3.2"
__all__ = [
    "AgentWatchClient", 
    "AgentWatchFastMCPClient",
    "Client", 
    "LogStage", 
    "LogEntry", 
    "ApplicationNames",
    "OAuth2Client",
    "FixedTokenClient",
    "MixedAuthClient",
    "NoAuthClient",
    "create_auth_client",
    "AgentWatchMCPDecorator",
    "create_agent_watch_mcp_decorator",
    "setup_global_decorator",
    "logged_tool",
    "AgentWatchDecorator",
    "create_agent_watch_decorator",
    "setup_standalone_decorator",
    "get_global_decorator",
    "receive_func",
    "send_func",
    "set_context",
    "get_context"
]


class ApplicationNames:
    """Common application names as per specification"""
    SALES_AGENT = "salesAgent"
    MARKET_AGENT = "marketAgent"
    CON_AGENT = "conAgent"
    SERVICE_AGENT = "serviceAgent"
    PARTNER_AGENT = "partnerAgent"
    ROBBIE = "robbie"
    AI_FORCE = "aiForce"
    KM_VERSE = "kmVerse"
    AI_VERSE = "aiVerse"
    ETR = "etr"
