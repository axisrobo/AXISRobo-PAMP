import requests
import time
import os
from typing import Optional, Dict, Any
from threading import Lock
from abc import ABC, abstractmethod


class AuthClient(ABC):
    """Abstract base class for authentication clients"""
    
    @abstractmethod
    def get_access_token(self) -> str:
        """Get access token for API authentication"""
        pass
    
    @abstractmethod
    def get_auth_headers(self) -> Dict[str, str]:
        """Get authentication headers"""
        pass


class OAuth2Client(AuthClient):
    """OAuth2 client credentials authentication"""
    
    def __init__(self, client_id: str, client_secret: str, token_url: str, verify_ssl: bool = True, ca_bundle: str = None):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token_url = token_url
        self.verify_ssl = verify_ssl
        self.ca_bundle = ca_bundle
        self._access_token: Optional[str] = None
        self._token_expires_at: float = 0
        self._lock = Lock()
        # Read default expires_in from environment variable, fallback to 3600
        self._default_expires_in = int(os.getenv('OAUTH2_DEFAULT_EXPIRES_IN', '3600'))
    
    def get_access_token(self) -> str:
        with self._lock:
            if self._access_token and time.time() < self._token_expires_at:
                return self._access_token
            
            return self._refresh_token()
    
    def get_auth_headers(self) -> Dict[str, str]:
        """Get OAuth2 authentication headers"""
        token = self.get_access_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    
    def _refresh_token(self) -> str:
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret
        }
        
        # Configure SSL verification
        verify = self.verify_ssl
        if not self.verify_ssl:
            verify = False
        elif self.ca_bundle:
            verify = self.ca_bundle
        
        response = requests.post(self.token_url, data=data, verify=verify)
        response.raise_for_status()
        
        token_data = response.json()
        self._access_token = token_data["access_token"]
        expires_in = token_data.get("expires_in", self._default_expires_in)
        self._token_expires_at = time.time() + expires_in - 60  # Refresh 1 minute early
        
        return self._access_token


class FixedTokenClient(AuthClient):
    """Fixed token authentication from environment variables"""
    
    def __init__(self, token_env_var: str = 'AGENT_WATCH_TOKEN', 
                 custom_headers_env_var: str = 'AGENT_WATCH_CUSTOM_HEADERS',
                 fixed_token_header_key: str = 'X-Auth-Token'):
        self.token_env_var = token_env_var
        self.custom_headers_env_var = custom_headers_env_var
        self.fixed_token_header_key = fixed_token_header_key
        self._custom_headers = self._load_custom_headers()
    
    def get_access_token(self) -> str:
        """Get fixed token from environment variable"""
        token = os.getenv(self.token_env_var)
        if not token:
            raise ValueError(f"Environment variable '{self.token_env_var}' is not set")
        return token
    
    def get_auth_headers(self) -> Dict[str, str]:
        """Get fixed token authentication headers"""
        token = self.get_access_token()
        headers = {
            "Content-Type": "application/json"
        }
        
        # Add token with specified header key
        if self.fixed_token_header_key.lower() == 'authorization':
            headers[self.fixed_token_header_key] = f"Bearer {token}"
        else:
            headers[self.fixed_token_header_key] = token
        
        # Add custom headers if configured
        if self._custom_headers:
            headers.update(self._custom_headers)
            
        return headers
    
    def _load_custom_headers(self) -> Dict[str, str]:
        """Load custom headers from environment variable"""
        custom_headers_str = os.getenv(self.custom_headers_env_var)
        if not custom_headers_str:
            return {}
        
        try:
            import json
            return json.loads(custom_headers_str)
        except (json.JSONDecodeError, TypeError) as e:
            print(f"Warning: Failed to parse custom headers from {self.custom_headers_env_var}: {e}")
            return {}



class APIHaborClient(AuthClient):
    """APIHabor authentication client"""
    
    def __init__(self, username: str, password: str, token_url: str, api_key: str, verify_ssl: bool = True, ca_bundle: str = None):
        """
        Initialize APIHabor authentication client
        
        Args:
            username: Username for authentication
            password: Password for authentication
            token_url: URL to get token from APIHabor
            api_key: API key for X-API-KEY header
            verify_ssl: Whether to verify SSL certificates (default: True)
            ca_bundle: Path to CA certificate bundle (optional)
        """
        self.username = username
        self.password = password
        self.token_url = token_url
        self.api_key = api_key
        self.verify_ssl = verify_ssl
        self.ca_bundle = ca_bundle
        self._access_token: Optional[str] = None
        self._token_expires_at: float = 0
        self._lock = Lock()
        # Default expires_in from environment variable, fallback to 300 (APIHabor default)
        self._default_expires_in = int(os.getenv('APIHARBOR_DEFAULT_EXPIRES_IN', '300'))
    
    def get_access_token(self) -> str:
        """Get access token for APIHabor authentication"""
        with self._lock:
            if self._access_token and time.time() < self._token_expires_at:
                return self._access_token
            
            return self._refresh_token()
    
    def get_auth_headers(self) -> Dict[str, str]:
        """Get APIHabor authentication headers with both Authorization and X-API-KEY"""
        token = self.get_access_token()
        return {
            "Authorization": f"{token}",
            "X-API-KEY": self.api_key,
            "Content-Type": "application/json"
        }
    
    def _refresh_token(self) -> str:
        """Refresh token using APIHabor authentication API"""
        headers = {
            "X-API-KEY": self.api_key,
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        data = {
            "username": self.username,
            "password": self.password
        }
        
        # Configure SSL verification
        verify = self.verify_ssl
        if not self.verify_ssl:
            verify = False
        elif self.ca_bundle:
            verify = self.ca_bundle
        
        response = requests.post(self.token_url, headers=headers, data=data, verify=verify)
        response.raise_for_status()
        
        token_data = response.json()
        self._access_token = token_data["access_token"]
        expires_in = token_data.get("expires_in", self._default_expires_in)
        self._token_expires_at = time.time() + expires_in - 30  # Refresh 30 seconds early
        
        return self._access_token


class MixedAuthClient(AuthClient):
    """Mixed authentication client that can combine multiple authentication methods"""
    
    def __init__(self, auth_clients: list, require_all: bool = False, primary_client_index: int = 0):
        """
        Initialize mixed authentication client with multiple auth clients
        
        Args:
            auth_clients: List of AuthClient instances to combine
            require_all: If True, all authentication methods must succeed
            primary_client_index: Index of the primary client for get_access_token() (default: 0)
        """
        if not auth_clients:
            raise ValueError("At least one auth client must be provided")
        
        # Validate that OAuth2Client and APIHaborClient are not mixed (both use Authorization header)
        has_oauth2 = any(isinstance(client, OAuth2Client) for client in auth_clients)
        has_apiharbor = any(isinstance(client, APIHaborClient) for client in auth_clients)
        
        if has_oauth2 and has_apiharbor:
            raise ValueError("OAuth2Client and APIHaborClient cannot be mixed as they both use 'Authorization' header")
        
        self.auth_clients = auth_clients
        self.require_all = require_all
        self.primary_client_index = primary_client_index
        self._lock = Lock()
        
        # Validate primary client index
        if not 0 <= primary_client_index < len(auth_clients):
            raise ValueError(f"primary_client_index {primary_client_index} is out of range for {len(auth_clients)} clients")
    
    @classmethod
    def create_mixed_auth(cls, auth_configs: list, require_all: bool = False, primary_client_index: int = 0):
        """
        Create mixed client from a list of auth configurations
        
        Args:
            auth_configs: List of dicts, each containing auth type and parameters
            require_all: If True, all authentication methods must succeed
            primary_client_index: Index of the primary client for get_access_token()
            
        Example:
            auth_configs = [
                {
                    "type": "oauth2",
                    "client_id": "your-client-id",
                    "client_secret": "your-client-secret",
                    "token_url": "https://auth.example.com/token"
                },
                {
                    "type": "fixed_token",
                    "token_env_var": "AGENT_WATCH_TOKEN",
                    "fixed_token_header_key": "X-API-Token"
                }
            ]
        """
        if not auth_configs:
            raise ValueError("At least one auth configuration must be provided")
        
        auth_clients = []
        for config in auth_configs:
            auth_type = config.pop("type")
            client = create_auth_client(auth_type, **config)
            auth_clients.append(client)
        
        return cls(auth_clients, require_all=require_all, primary_client_index=primary_client_index)
    
    @classmethod
    def oauth2_with_fixed_token(cls, 
                               client_id: str, 
                               client_secret: str, 
                               token_url: str,
                               token_env_var: str = 'AGENT_WATCH_TOKEN',
                               fixed_token_header_key: str = 'X-API-Token',
                               require_both: bool = False,
                               verify_ssl: bool = True,
                               ca_bundle: str = None):
        """Create OAuth2 + FixedToken mixed client"""
        oauth2_client = OAuth2Client(client_id, client_secret, token_url, 
                                   verify_ssl=verify_ssl, ca_bundle=ca_bundle)
        fixed_token_client = FixedTokenClient(
            token_env_var=token_env_var,
            fixed_token_header_key=fixed_token_header_key
        )
        return cls([oauth2_client, fixed_token_client], require_all=require_both)
    
    @classmethod
    def apiharbor_with_fixed_token(cls,
                                  username: str,
                                  password: str,
                                  token_url: str,
                                  api_key: str,
                                  token_env_var: str = 'AGENT_WATCH_TOKEN',
                                  fixed_token_header_key: str = 'X-API-Token',
                                  require_both: bool = False,
                                  verify_ssl: bool = True,
                                  ca_bundle: str = None):
        """Create APIHabor + FixedToken mixed client"""
        apiharbor_client = APIHaborClient(username, password, token_url, api_key,
                                        verify_ssl=verify_ssl, ca_bundle=ca_bundle)
        fixed_token_client = FixedTokenClient(
            token_env_var=token_env_var,
            fixed_token_header_key=fixed_token_header_key
        )
        return cls([apiharbor_client, fixed_token_client], require_all=require_both)

    def get_auth_headers(self) -> Dict[str, str]:
        """Get combined authentication headers from all clients"""
        headers = {
            "Content-Type": "application/json"
        }
        
        successful_clients = []
        failed_clients = []
        
        for i, client in enumerate(self.auth_clients):
            try:
                client_headers = client.get_auth_headers()
                # Remove Content-Type to avoid duplication
                if "Content-Type" in client_headers:
                    del client_headers["Content-Type"]
                
                # Merge headers, handling conflicts intelligently
                for key, value in client_headers.items():
                    if key in headers and headers[key] != value:
                        # Handle conflicts by prefixing with client type
                        client_type = type(client).__name__.replace('Client', '').lower()
                        conflict_key = f"{key}-{client_type}"
                        headers[conflict_key] = value
                    else:
                        headers[key] = value
                
                successful_clients.append(f"{type(client).__name__}[{i}]")
                
            except Exception as e:
                failed_clients.append((f"{type(client).__name__}[{i}]", str(e)))
                if self.require_all:
                    raise Exception(f"Authentication failed for {type(client).__name__}[{i}] (required): {e}")
        
        # Check if at least one client succeeded
        if not successful_clients:
            error_details = "; ".join([f"{name}: {error}" for name, error in failed_clients])
            raise Exception(f"All authentication methods failed: {error_details}")
        
        return headers
    
    def get_access_token(self) -> str:
        """Get access token from the primary client"""
        try:
            return self.auth_clients[self.primary_client_index].get_access_token()
        except Exception as e:
            raise Exception(f"Failed to get access token from primary client {type(self.auth_clients[self.primary_client_index]).__name__}[{self.primary_client_index}]: {e}")
    
    def get_auth_status(self) -> Dict[str, Any]:
        """Get status of all authentication methods"""
        status = {
            "clients": [],
            "successful_count": 0,
            "failed_count": 0,
            "require_all": self.require_all,
            "primary_client": self.primary_client_index
        }
        
        for i, client in enumerate(self.auth_clients):
            client_status = {
                "index": i,
                "type": type(client).__name__,
                "available": False,
                "error": None,
                "is_primary": i == self.primary_client_index
            }
            
            try:
                client.get_access_token()
                client_status["available"] = True
                status["successful_count"] += 1
            except Exception as e:
                client_status["error"] = str(e)
                status["failed_count"] += 1
            
            status["clients"].append(client_status)
        
        return status


class NoAuthClient(AuthClient):
    """No authentication client for development/testing"""
    
    def get_access_token(self) -> str:
        """Return empty token for no-auth scenarios"""
        return ""
    
    def get_auth_headers(self) -> Dict[str, str]:
        """Get headers without authentication"""
        return {
            "Content-Type": "application/json"
        }


def create_auth_client(auth_type: str = "oauth2", **kwargs) -> AuthClient:
    """Factory function to create authentication clients
    
    Args:
        auth_type: Type of authentication ('oauth2', 'apiharbor', 'fixed_token', 'mixed', 'none')
        **kwargs: Additional parameters for specific auth types
        
    Returns:
        AuthClient instance
        
    Examples:
        # OAuth2 authentication
        auth_client = create_auth_client(
            auth_type="oauth2",
            client_id="your-client-id",
            client_secret="your-client-secret", 
            token_url="https://auth.example.com/token"
        )
        
        # APIHabor authentication  
        auth_client = create_auth_client(
            auth_type="apiharbor",
            username="your-username",
            password="your-password",
            token_url="https://api.example.com/auth/token",
            api_key="your-api-key"
        )
        
        # Fixed token authentication
        auth_client = create_auth_client(
            auth_type="fixed_token",
            token_env_var="MY_API_TOKEN",
            fixed_token_header_key="X-API-Token"
        )
        
        # Mixed authentication with configuration list
        auth_client = create_auth_client(
            auth_type="mixed",
            auth_configs=[
                {
                    "type": "oauth2",
                    "client_id": "your-client-id", 
                    "client_secret": "your-client-secret",
                    "token_url": "https://auth.example.com/token"
                },
                {
                    "type": "fixed_token",
                    "token_env_var": "AGENT_WATCH_TOKEN",
                    "fixed_token_header_key": "X-API-Token"
                }
            ],
            require_all=False,
            primary_client_index=0
        )
        
        # Mixed with pre-created clients
        auth_client = create_auth_client(
            auth_type="mixed",
            auth_clients=[oauth2_client, fixed_token_client],
            require_all=False
        )
        
        # Quick mixed OAuth2 + FixedToken
        auth_client = MixedAuthClient.oauth2_with_fixed_token(
            client_id="your-client-id",
            client_secret="your-client-secret", 
            token_url="https://auth.example.com/token",
            token_env_var="AGENT_WATCH_TOKEN"
        )
        
        # Quick mixed APIHabor + FixedToken  
        auth_client = MixedAuthClient.apiharbor_with_fixed_token(
            username="your-username",
            password="your-password",
            token_url="https://api.example.com/auth/token", 
            api_key="your-api-key",
            token_env_var="AGENT_WATCH_TOKEN"
        )
        
        # No authentication
        auth_client = create_auth_client(auth_type="none")
    """
    if auth_type == "oauth2":
        required_params = ["client_id", "client_secret", "token_url"]
        for param in required_params:
            if param not in kwargs:
                raise ValueError(f"Parameter '{param}' is required for OAuth2 authentication")
        
        return OAuth2Client(
            client_id=kwargs["client_id"],
            client_secret=kwargs["client_secret"],
            token_url=kwargs["token_url"],
            verify_ssl=kwargs.get("verify_ssl", True),
            ca_bundle=kwargs.get("ca_bundle")
        )
    
    elif auth_type == "apiharbor":
        required_params = ["username", "password", "token_url", "api_key"]
        for param in required_params:
            if param not in kwargs:
                raise ValueError(f"Parameter '{param}' is required for APIHabor authentication")
        
        return APIHaborClient(
            username=kwargs["username"],
            password=kwargs["password"],
            token_url=kwargs["token_url"],
            api_key=kwargs["api_key"],
            verify_ssl=kwargs.get("verify_ssl", True),
            ca_bundle=kwargs.get("ca_bundle")
        )
    
    elif auth_type == "fixed_token":
        return FixedTokenClient(
            token_env_var=kwargs.get("token_env_var", "AGENT_WATCH_TOKEN"),
            custom_headers_env_var=kwargs.get("custom_headers_env_var", "AGENT_WATCH_CUSTOM_HEADERS"),
            fixed_token_header_key=kwargs.get("fixed_token_header_key", "X-Auth-Token")
        )
    
    elif auth_type == "mixed":
        # Support both auth_configs (list of configs) and auth_clients (list of instances)
        if "auth_configs" in kwargs:
            return MixedAuthClient.create_mixed_auth(
                auth_configs=kwargs["auth_configs"],
                require_all=kwargs.get("require_all", False),
                primary_client_index=kwargs.get("primary_client_index", 0)
            )
        elif "auth_clients" in kwargs:
            return MixedAuthClient(
                auth_clients=kwargs["auth_clients"],
                require_all=kwargs.get("require_all", False),
                primary_client_index=kwargs.get("primary_client_index", 0)
            )
        # Convenience method: if OAuth2 params are provided, create OAuth2+FixedToken mixed auth
        elif "client_id" in kwargs and "client_secret" in kwargs and "token_url" in kwargs:
            return MixedAuthClient.oauth2_with_fixed_token(
                client_id=kwargs["client_id"],
                client_secret=kwargs["client_secret"],
                token_url=kwargs["token_url"],
                token_env_var=kwargs.get("token_env_var", "AGENT_WATCH_TOKEN"),
                fixed_token_header_key=kwargs.get("fixed_token_header_key", "X-Auth-Token"),
                require_both=kwargs.get("require_both", kwargs.get("require_all", False)),
                verify_ssl=kwargs.get("verify_ssl", True),
                ca_bundle=kwargs.get("ca_bundle")
            )
        # Convenience method: if APIHarbor params are provided, create APIHarbor+FixedToken mixed auth
        elif "username" in kwargs and "password" in kwargs and "token_url" in kwargs and "api_key" in kwargs:
            return MixedAuthClient.apiharbor_with_fixed_token(
                username=kwargs["username"],
                password=kwargs["password"],
                token_url=kwargs["token_url"],
                api_key=kwargs["api_key"],
                token_env_var=kwargs.get("token_env_var", "AGENT_WATCH_TOKEN"),
                fixed_token_header_key=kwargs.get("fixed_token_header_key", "X-Auth-Token"),
                require_both=kwargs.get("require_both", kwargs.get("require_all", False)),
                verify_ssl=kwargs.get("verify_ssl", True),
                ca_bundle=kwargs.get("ca_bundle")
            )
        else:
            raise ValueError("Parameter 'auth_configs' (list of config dicts) or 'auth_clients' (list of AuthClient instances) is required for mixed authentication. Alternatively, provide OAuth2 parameters (client_id, client_secret, token_url) or APIHarbor parameters (username, password, token_url, api_key) for convenience.")
    
    elif auth_type == "none":
        return NoAuthClient()
    
    elif auth_type == "mixed_oauth2_fixed":
        # Backward compatibility for existing mixed auth
        required_params = ["client_id", "client_secret", "token_url"]
        for param in required_params:
            if param not in kwargs:
                raise ValueError(f"Parameter '{param}' is required for mixed OAuth2+FixedToken authentication")
        
        return MixedAuthClient.create_oauth2_fixed_token(
            client_id=kwargs["client_id"],
            client_secret=kwargs["client_secret"],
            token_url=kwargs["token_url"],
            token_env_var=kwargs.get("token_env_var", "AGENT_WATCH_TOKEN"),
            custom_headers_env_var=kwargs.get("custom_headers_env_var", "AGENT_WATCH_CUSTOM_HEADERS"),
            require_both=kwargs.get("require_both", False),
            oauth2_header_key=kwargs.get("oauth2_header_key", "Authorization"),
            fixed_token_header_key=kwargs.get("fixed_token_header_key", "X-API-Token")
        )
    
    elif auth_type == "mixed_apiharbor_fixed":
        required_params = ["username", "password", "apiharbor_token_url", "api_key"]
        for param in required_params:
            if param not in kwargs:
                raise ValueError(f"Parameter '{param}' is required for mixed APIHabor+FixedToken authentication")
        
        return MixedAuthClient.create_apiharbor_fixed_token(
            username=kwargs["username"],
            password=kwargs["password"],
            apiharbor_token_url=kwargs["apiharbor_token_url"],
            api_key=kwargs["api_key"],
            token_env_var=kwargs.get("token_env_var", "AGENT_WATCH_TOKEN"),
            custom_headers_env_var=kwargs.get("custom_headers_env_var", "AGENT_WATCH_CUSTOM_HEADERS"),
            require_both=kwargs.get("require_both", False),
            fixed_token_header_key=kwargs.get("fixed_token_header_key", "X-API-Token")
        )
    
    elif auth_type == "mixed_oauth2_apiharbor":
        required_params = ["client_id", "client_secret", "oauth2_token_url", "username", "password", "apiharbor_token_url", "api_key"]
        for param in required_params:
            if param not in kwargs:
                raise ValueError(f"Parameter '{param}' is required for mixed OAuth2+APIHabor authentication")
        
        return MixedAuthClient.create_oauth2_apiharbor(
            client_id=kwargs["client_id"],
            client_secret=kwargs["client_secret"],
            oauth2_token_url=kwargs["oauth2_token_url"],
            username=kwargs["username"],
            password=kwargs["password"],
            apiharbor_token_url=kwargs["apiharbor_token_url"],
            api_key=kwargs["api_key"],
            require_both=kwargs.get("require_both", False)
        )
    
    elif auth_type == "mixed_all_three":
        required_params = ["client_id", "client_secret", "oauth2_token_url", "username", "password", "apiharbor_token_url", "api_key"]
        for param in required_params:
            if param not in kwargs:
                raise ValueError(f"Parameter '{param}' is required for mixed OAuth2+APIHabor+FixedToken authentication")
        
        return MixedAuthClient.create_all_three(
            client_id=kwargs["client_id"],
            client_secret=kwargs["client_secret"],
            oauth2_token_url=kwargs["oauth2_token_url"],
            username=kwargs["username"],
            password=kwargs["password"],
            apiharbor_token_url=kwargs["apiharbor_token_url"],
            api_key=kwargs["api_key"],
            token_env_var=kwargs.get("token_env_var", "AGENT_WATCH_TOKEN"),
            custom_headers_env_var=kwargs.get("custom_headers_env_var", "AGENT_WATCH_CUSTOM_HEADERS"),
            require_all=kwargs.get("require_all", False),
            fixed_token_header_key=kwargs.get("fixed_token_header_key", "X-API-Token")
        )
    
    else:
        raise ValueError(f"Unsupported auth_type: {auth_type}. Supported types: oauth2, apiharbor, fixed_token, mixed, mixed_oauth2_fixed, mixed_apiharbor_fixed, mixed_oauth2_apiharbor, mixed_all_three, none")
