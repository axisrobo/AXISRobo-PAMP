import requests
import uuid
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Union
from .auth import AuthClient, OAuth2Client, create_auth_client
from .models import LogStage, LogEntry


class AgentWatchClient:
    def __init__(self, collector_url: str, application_name: str, chatbot_name: Optional[str] = None,
                 auth_client: Optional[AuthClient] = None,
                 # OAuth2 parameters (for backward compatibility)
                 client_id: Optional[str] = None,
                 client_secret: Optional[str] = None, 
                 token_url: Optional[str] = None,
                 # Alternative auth configuration
                 auth_type: str = "oauth2",
                 # SSL configuration
                 verify_ssl: bool = True,
                 ca_bundle: Optional[str] = None,
                 **auth_kwargs):
        """
        Initialize AgentWatchClient with flexible authentication options
        
        Args:
            collector_url: URL of the Agent Watch Collector
            application_name: Name of the current application
            chatbot_name: Name of the chatbot
            auth_client: Pre-configured authentication client
            client_id: OAuth2 client ID (for backward compatibility)
            client_secret: OAuth2 client secret (for backward compatibility)
            token_url: OAuth2 token URL (for backward compatibility)
            auth_type: Type of authentication ('oauth2', 'fixed_token', 'none')
            verify_ssl: Whether to verify SSL certificates (default: True)
            ca_bundle: Path to CA certificate bundle file (optional)
            **auth_kwargs: Additional authentication parameters
            
        Examples:
            # OAuth2 authentication (backward compatible)
            client = AgentWatchClient(
                collector_url="https://collector.example.com",
                client_id="your-client-id",
                client_secret="your-client-secret",
                token_url="https://auth.example.com/token",
                application_name="salesAgent",
                chatbot_name="salesAgent"
            )
            
            # Fixed token authentication
            client = AgentWatchClient(
                collector_url="https://collector.example.com",
                application_name="salesAgent",
                chatbot_name="salesAgent",
                auth_type="fixed_token"
            )
            
            # No authentication
            client = AgentWatchClient(
                collector_url="https://collector.example.com",
                application_name="salesAgent",
                chatbot_name="salesAgent",
                auth_type="none"
            )
            
            # Disable SSL verification (for testing environments)
            client = AgentWatchClient(
                collector_url="https://test-collector.example.com",
                application_name="salesAgent",
                chatbot_name="salesAgent",
                auth_type="fixed_token",
                verify_ssl=False
            )
            
            # Custom CA bundle
            client = AgentWatchClient(
                collector_url="https://collector.example.com",
                application_name="salesAgent",
                chatbot_name="salesAgent",
                auth_type="fixed_token",
                ca_bundle="/path/to/ca-bundle.crt"
            )
            
            # Custom auth client
            custom_auth = create_auth_client("fixed_token", token_env_var="MY_TOKEN")
            client = AgentWatchClient(
                collector_url="https://collector.example.com",
                application_name="salesAgent",
                chatbot_name="salesAgent",
                auth_client=custom_auth
            )
        """
        self.collector_url = collector_url.rstrip('/')
        self.application_name = application_name
        self.chatbot_name = chatbot_name  # 现在可以为 None，作为默认值使用
        self.session = requests.Session()
        
        # Configure SSL verification
        self.verify_ssl = verify_ssl
        if ca_bundle:
            self.session.verify = ca_bundle
        elif not verify_ssl:
            self.session.verify = False
            # Suppress SSL warnings when verification is disabled
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # Initialize authentication client
        if auth_client:
            self.auth_client = auth_client
        elif client_id and client_secret and token_url:
            # Backward compatibility: create OAuth2 client from individual parameters
            self.auth_client = OAuth2Client(client_id, client_secret, token_url)
        else:
            # Create auth client based on auth_type
            # Include explicit auth parameters in auth_kwargs
            all_auth_params = dict(auth_kwargs)
            if token_url:
                all_auth_params['token_url'] = token_url
            if client_id:
                all_auth_params['client_id'] = client_id
            if client_secret:
                all_auth_params['client_secret'] = client_secret
            
            # Add SSL verification parameters
            all_auth_params['verify_ssl'] = verify_ssl
            if ca_bundle:
                all_auth_params['ca_bundle'] = ca_bundle
                
            if auth_type == "oauth2":
                # For OAuth2, check if parameters are provided
                oauth_params = {
                    "client_id": all_auth_params.get("client_id"),
                    "client_secret": all_auth_params.get("client_secret"),
                    "token_url": all_auth_params.get("token_url"),
                    "verify_ssl": verify_ssl,
                }
                if ca_bundle:
                    oauth_params["ca_bundle"] = ca_bundle
                if not all([oauth_params.get("client_id"), oauth_params.get("client_secret"), oauth_params.get("token_url")]):
                    raise ValueError("OAuth2 authentication requires client_id, client_secret, and token_url")
                self.auth_client = create_auth_client(auth_type, **oauth_params)
            else:
                self.auth_client = create_auth_client(auth_type, **all_auth_params)
    
    def _send_log(self, log_entry: LogEntry) -> bool:
        try:
            
            headers = self.auth_client.get_auth_headers()
            
            response = self.session.post(
                f"{self.collector_url}/log",
                json=log_entry.to_dict(),
                headers=headers
            )
            response.raise_for_status()
            return True
        except Exception as e:
            print(f"Failed to send log: {e}")
            return False
    
    def receive_request(self, session_id: str, trace_id: str, span_id: str,
                       source_application: str,
                       parent_span_id: Optional[str] = None,
                       input_data: Optional[Dict[str, Any]] = None,
                       user_id: Optional[str] = None,
                       chatbot_name: Optional[str] = None,
                       action: Optional[str] = None,
                       tags: Optional[List[str]] = None,
                       custom_property: Optional[Dict[str, Any]] = None,
                       receive_timestamp: Optional[datetime] = None,
                       scenario: Optional[str] = None) -> bool:
        
        # Use provided timestamp or current time
        current_time = receive_timestamp or datetime.now(timezone.utc)
        
        log_entry = LogEntry(
            session_id=session_id,
            trace_id=trace_id,
            span_id=span_id,
            stage=LogStage.RECEIVE_REQUEST,
            timestamp=current_time,
            source_application=source_application,
            target_application=self.application_name,  # Current application is the target
            chatbot_name=chatbot_name or self.chatbot_name,  # Use parameter or fallback to client's chatbot_name
            parent_span_id=parent_span_id,
            user_id=user_id,
            action=action,
            input=input_data,
            receive_timestamp=current_time,
            tags=tags,
            custom_property=custom_property,
            scenario=scenario,
        )
        return self._send_log(log_entry)
    
    def send_request(self, session_id: str, trace_id: str, span_id: str,
                    target_application: str,
                    parent_span_id: Optional[str] = None,
                    input_data: Optional[Dict[str, Any]] = None,
                    user_id: Optional[str] = None,
                    chatbot_name: Optional[str] = None,
                    action: Optional[str] = None,
                    tags: Optional[List[str]] = None,
                    custom_property: Optional[Dict[str, Any]] = None,
                    send_timestamp: Optional[datetime] = None,
                    scenario: Optional[str] = None) -> bool:
        
        # Use provided timestamp or current time
        current_time = send_timestamp or datetime.now(timezone.utc)
        
        log_entry = LogEntry(
            session_id=session_id,
            trace_id=trace_id,
            span_id=span_id,
            stage=LogStage.SEND_REQUEST,
            timestamp=current_time,
            source_application=self.application_name,  # Current application is the source
            target_application=target_application,
            chatbot_name=chatbot_name or self.chatbot_name,  # Use parameter or fallback to client's chatbot_name
            parent_span_id=parent_span_id,
            user_id=user_id,
            action=action,
            input=input_data,
            send_timestamp=current_time,
            tags=tags,
            custom_property=custom_property,
            scenario=scenario
        )
        return self._send_log(log_entry)
    
    def receive_response(self, session_id: str, trace_id: str, span_id: str,
                        status_code: int,
                        source_application: str,
                        parent_span_id: Optional[str] = None,
                        output: Optional[str] = None,
                        output_type: Optional[str] = None,
                        send_timestamp: Optional[datetime] = None,
                        first_token_timestamp: Optional[datetime] = None,
                        result: str = "succeed",
                        error_detail: Optional[str] = None,
                        user_id: Optional[str] = None,
                        chatbot_name: Optional[str] = None,
                        action: Optional[str] = None,
                        tags: Optional[List[str]] = None,
                        custom_property: Optional[Dict[str, Any]] = None,
                        receive_timestamp: Optional[datetime] = None,
                        scenario: Optional[str] = None) -> bool:
        
        # Use provided timestamp or current time
        current_time = receive_timestamp or datetime.now(timezone.utc)
        
        # Calculate metrics
        response_time = None
        first_token_duration = None
        if send_timestamp:
            response_time = int((current_time - send_timestamp).total_seconds() * 1000)
        if first_token_timestamp and send_timestamp:
            first_token_duration = int((first_token_timestamp - send_timestamp).total_seconds() * 1000)
        
        log_entry = LogEntry(
            session_id=session_id,
            trace_id=trace_id,
            span_id=span_id,
            stage=LogStage.RECEIVE_RESPONSE,
            timestamp=current_time,
            source_application=source_application,  # Third-party application is the source
            target_application=self.application_name,  # Current application is the target
            chatbot_name=chatbot_name or self.chatbot_name,  # Use parameter or fallback to client's chatbot_name
            parent_span_id=parent_span_id,
            user_id=user_id,
            action=action,
            output=output,
            output_type=output_type,
            first_token_timestamp=first_token_timestamp,
            first_token_duration=first_token_duration,
            receive_timestamp=current_time,
            status=status_code,
            response_time=response_time,
            result=result,
            error_detail=error_detail,
            tags=tags,
            custom_property=custom_property,
            severity_text="ERROR" if result == "failed" else "INFO",
            scenario=scenario
        )
        return self._send_log(log_entry)
    
    def send_response(self, session_id: str, trace_id: str, span_id: str,
                     status_code: int,
                     target_application: str,
                     parent_span_id: Optional[str] = None,
                     output: Optional[str] = None,
                     output_type: Optional[str] = None,
                     first_token_timestamp: Optional[datetime] = None,
                     result: str = "succeed",
                     user_id: Optional[str] = None,
                     chatbot_name: Optional[str] = None,
                     action: Optional[str] = None,
                     tags: Optional[List[str]] = None,
                     custom_property: Optional[Dict[str, Any]] = None,
                     send_timestamp: Optional[datetime] = None,
                     scenario: Optional[str] = None) -> bool:
        
        # Use provided timestamp or current time
        current_time = send_timestamp or datetime.now(timezone.utc)
        
        log_entry = LogEntry(
            session_id=session_id,
            trace_id=trace_id,
            span_id=span_id,
            stage=LogStage.SEND_RESPONSE,
            timestamp=current_time,
            source_application=self.application_name,  # Current application is the source
            target_application=target_application,  # Third-party application is the target
            chatbot_name=chatbot_name or self.chatbot_name,  # Use parameter or fallback to client's chatbot_name
            parent_span_id=parent_span_id,
            user_id=user_id,
            action=action,
            output=output,
            output_type=output_type,
            first_token_timestamp=first_token_timestamp,
            result=result,
            send_timestamp=current_time,
            status=status_code,
            tags=tags,
            custom_property=custom_property,
            scenario=scenario
        )
        return self._send_log(log_entry)
    
    def generate_trace_id(self) -> str:
        return str(uuid.uuid4())
    
    def generate_span_id(self) -> str:
        return str(uuid.uuid4())
    
    def get_trace_headers(self, session_id: str, trace_id: str, span_id: str, parent_span_id: Optional[str] = None) -> Dict[str, str]:
        """Generate headers for trace propagation"""
        headers = {
            "sessionId": session_id,
            "traceId": trace_id,
            "spanId": span_id,
            "sourceApplication": self.application_name,
            "chatbotName": self.chatbot_name
        }
        if parent_span_id:
            headers["parentSpanId"] = parent_span_id
        return headers
