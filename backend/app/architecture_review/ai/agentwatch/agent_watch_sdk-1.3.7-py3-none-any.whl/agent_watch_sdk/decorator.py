"""
Agent Watch SDK 独立装饰器模块

提供独立的装饰器类 AgentWatchDecorator，用于管理追踪上下文和日志记录。
包含 receive_func 和 send_func 两个装饰器，用于不同的调用场景。
"""

import functools
import uuid
import inspect
import threading
import json
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional, TypeVar, Union, List
from contextvars import ContextVar

from .client import AgentWatchClient
from .models import LogStage, LogEntry

F = TypeVar('F', bound=Callable[..., Any])

# 用于存储追踪上下文的上下文变量
_session_id_context: ContextVar[Optional[str]] = ContextVar('session_id', default=None)
_trace_id_context: ContextVar[Optional[str]] = ContextVar('trace_id', default=None)
_span_id_context: ContextVar[Optional[str]] = ContextVar('span_id', default=None)
_parent_span_id_context: ContextVar[Optional[str]] = ContextVar('parent_span_id', default=None)
_source_application_context: ContextVar[Optional[str]] = ContextVar('source_application', default=None)
_user_id_context: ContextVar[Optional[str]] = ContextVar('user_id', default=None)
_chatbot_name_context: ContextVar[Optional[str]] = ContextVar('chatbot_name', default=None)
_custom_property_context: ContextVar[Optional[Dict[str, Any]]] = ContextVar('custom_property', default=None)

# 工作流相关的上下文变量
_workflow_context: ContextVar[Optional[Dict[str, Any]]] = ContextVar('workflow_context', default=None)
_workflow_stack: ContextVar[Optional[List[Dict[str, Any]]]] = ContextVar('workflow_stack', default=None)


class ContextManager:
    """
    全局上下文管理器（单例），负责维护调用链路的ID关系
    
    确保：
    - Session ID: 整个用户会话保持不变
    - Trace ID: 一个完整的业务场景保持不变  
    - Span ID: 每个服务调用（send_request + receive_response）使用同一个span_id
    - Parent Span ID: 正确设置调用层级关系
    """
    
    _instance: Optional['ContextManager'] = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                # 双重检查锁定
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        # 避免重复初始化
        if hasattr(self, '_initialized'):
            return
        
        # 用于追踪当前调用栈，使用 threading.local() 确保线程安全
        self._local = threading.local()
        self._initialized = True
    
    @property
    def _call_stack(self) -> List[Dict[str, Any]]:
        """获取当前线程的调用栈"""
        if not hasattr(self._local, 'call_stack'):
            self._local.call_stack = []
        return self._local.call_stack
    
    def start_receive_call(
        self, 
        session_id: Optional[str] = None, 
        trace_id: Optional[str] = None, 
        span_id: Optional[str] = None, 
        parent_span_id: Optional[str] = None,
        source_application: Optional[str] = None,
        user_id: Optional[str] = None,
        chatbot_name: Optional[str] = None,
        custom_property: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        开始一个receive调用
        
        Args:
            session_id: 会话ID
            trace_id: 追踪ID
            span_id: 跨度ID (如果未提供，将从调用栈中获取或生成)
            parent_span_id: 父跨度ID
            source_application: 来源应用
            user_id: 用户ID
            chatbot_name: 聊天机器人名称
            custom_property: 自定义属性
            **kwargs: 其他参数
            
        Returns:
            上下文字典
        """
        # 如果是顶层调用，初始化session_id和trace_id
        if not self._call_stack:
            session_id = session_id or str(uuid.uuid4())
            trace_id = trace_id or str(uuid.uuid4())
            span_id = span_id or str(uuid.uuid4())
            parent_span_id = span_id
        else:
            # 继承上层的session_id和trace_id
            current_context = self._call_stack[-1]
            session_id = session_id or current_context['session_id']
            trace_id = trace_id or current_context['trace_id']
            chatbot_name = chatbot_name or current_context['chatbot_name']
            source_application = source_application or current_context['source_application']
            # 如果没有传入span_id，说明这是一个新的receive调用，应该使用调用者传递的span_id
            if span_id is None:
                # 如果调用者有new_span_id，使用它；否则生成新的span_id
                span_id = current_context.get('new_span_id') or str(uuid.uuid4())
            
            # 如果没有传入parent_span_id，使用上层的span_id
            if parent_span_id is None and span_id == current_context.get('span_id'):
                parent_span_id = current_context.get('parent_span_id') or current_context.get('span_id')
            elif parent_span_id is None:
                parent_span_id = current_context.get('span_id')
        
        context = {
            'session_id': session_id,
            'trace_id': trace_id,
            'span_id': span_id,
            'parent_span_id': parent_span_id,
            'source_application': source_application or 'unknown',
            'user_id': user_id,
            'chatbot_name': chatbot_name,
            'custom_property': custom_property,
            'call_type': 'receive',
            **kwargs
        }
        
        self._call_stack.append(context)
        self._set_context_vars(context)
        return context
    
    def start_send_call(
        self, 
        target_application: str,
        action: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        开始一个send调用
        
        Args:
            target_application: 目标应用名称
            action: 操作名称
            **kwargs: 其他参数
            
        Returns:
            上下文字典
        """
        if not self._call_stack:
            # 如果没有receive_call上下文，生成新的上下文作为顶层调用
            session_id = kwargs.get('session_id') or str(uuid.uuid4())
            trace_id = kwargs.get('trace_id') or str(uuid.uuid4())
            span_id = kwargs.get('span_id') or str(uuid.uuid4())
            parent_span_id = kwargs.get('parent_span_id') or span_id
            source_application = kwargs.get('source_application') or 'unknown'
            user_id = kwargs.get('user_id')
            chatbot_name = kwargs.get('chatbot_name')
            custom_property = kwargs.get('custom_property')
            
            context = {
                'session_id': session_id,
                'trace_id': trace_id,
                'span_id': span_id,
                'parent_span_id': parent_span_id,
                'source_application': source_application,
                'user_id': user_id,
                'chatbot_name': chatbot_name,
                'custom_property': custom_property,
                'call_type': 'send',
                'target_application': target_application,
                'action': action,
                'new_span_id': span_id,  # 记录新span_id，供后续receive使用
            }
        else:
            # 继承当前上下文
            current_context = self._call_stack[-1]
            
            source_application = kwargs.get('source_application') or current_context.get('source_application')

            
            # 生成新的span_id用于这次调用
            new_span_id = str(uuid.uuid4())
            
            context = {
                'session_id': current_context['session_id'],
                'trace_id': current_context['trace_id'],
                'span_id': new_span_id,
                'parent_span_id': current_context['span_id'],
                'source_application': source_application,
                'user_id': current_context.get('user_id'),
                'chatbot_name': current_context.get('chatbot_name'),
                'custom_property': current_context.get('custom_property'),
                'call_type': 'send',
                'target_application': target_application,
                'action': action,
                'new_span_id': new_span_id,  # 记录新span_id，供后续receive使用
                **kwargs
            }
        
        self._call_stack.append(context)
        self._set_context_vars(context)
        return context
    
    def end_call(self):
        """结束当前调用"""
        if self._call_stack:
            self._call_stack.pop()
            
        # 恢复上一层的上下文
        if self._call_stack:
            self._set_context_vars(self._call_stack[-1])
        else:
            self._clear_context_vars()
    
    def get_current_context(self) -> Optional[Dict[str, Any]]:
        """获取当前上下文"""
        return self._call_stack[-1] if self._call_stack else None
    
    def _set_context_vars(self, context: Dict[str, Any]):
        """设置上下文变量"""
        if context.get('session_id'):
            _session_id_context.set(context['session_id'])
        if context.get('trace_id'):
            _trace_id_context.set(context['trace_id'])
        if context.get('span_id'):
            _span_id_context.set(context['span_id'])
        if context.get('parent_span_id'):
            _parent_span_id_context.set(context['parent_span_id'])
        if context.get('source_application'):
            _source_application_context.set(context['source_application'])
        if context.get('user_id'):
            _user_id_context.set(context['user_id'])
        if context.get('chatbot_name'):
            _chatbot_name_context.set(context['chatbot_name'])
        if context.get('custom_property'):
            _custom_property_context.set(context['custom_property'])
    
    def _clear_context_vars(self):
        """清理上下文变量"""
        _session_id_context.set(None)
        _trace_id_context.set(None)
        _span_id_context.set(None)
        _parent_span_id_context.set(None)
        _source_application_context.set(None)
        _user_id_context.set(None)
        _chatbot_name_context.set(None)
        _custom_property_context.set(None)


# 全局上下文管理器实例（单例）
_global_context_manager: Optional[ContextManager] = None


def get_global_context_manager() -> ContextManager:
    """
    获取全局上下文管理器实例
    
    Returns:
        全局 ContextManager 实例
    """
    global _global_context_manager
    if _global_context_manager is None:
        _global_context_manager = ContextManager()
    return _global_context_manager


class AgentWatchDecorator:
    """
    Agent Watch 独立装饰器类
    
    提供追踪上下文管理和两个装饰器方法：
    - receive_func: 用于接收端，记录 receive_request 和 send_response
    - send_func: 用于发送端，记录 send_request 和 receive_response
    """
    
    def __init__(self, client: AgentWatchClient, use_context_manager: bool = False):
        """
        初始化装饰器
        
        Args:
            client: AgentWatchClient 实例
            use_context_manager: 是否使用新的上下文管理器，默认为False保持向后兼容
        """
        self.client = client
        self._local = threading.local()
        self.use_context_manager = use_context_manager
    
    def _get_or_generate_context(self, call_type: str = "receive", **kwargs) -> Dict[str, Any]:
        """
        获取或生成追踪上下文
        
        优先级：
        1. 函数参数传入的值
        2. 上下文变量中的值
        3. 自动生成的值
        
        Args:
            call_type: 调用类型 ("receive" 或 "send")
            **kwargs: 可能包含追踪参数的关键字参数
            
        Returns:
            包含完整追踪上下文的字典
        """
        if self.use_context_manager:
            context_manager = get_global_context_manager()
            # 使用全局上下文管理器
            if call_type == "receive":
                # 只传递相关的上下文参数，过滤掉内部参数
                context_params = {
                    'session_id': kwargs.get('session_id'),
                    'trace_id': kwargs.get('trace_id'),
                    'span_id': kwargs.get('span_id'),
                    'parent_span_id': kwargs.get('parent_span_id'),
                    'source_application': kwargs.get('source_application'),
                    'user_id': kwargs.get('user_id'),
                    'chatbot_name': kwargs.get('chatbot_name'),
                    'custom_property': kwargs.get('custom_property'),
                }
                # 清理None值
                context_params = {k: v for k, v in context_params.items() if v is not None}
                return context_manager.start_receive_call(**context_params)
            elif call_type == "send":
                target_application = kwargs.get('target_application', 'external')
                action = kwargs.get('action', 'unknown')
                # 只传递相关的上下文参数，过滤掉内部参数
                context_params = {
                    'session_id': kwargs.get('session_id'),
                    'trace_id': kwargs.get('trace_id'),
                    'span_id': kwargs.get('span_id'),
                    'parent_span_id': kwargs.get('parent_span_id'),
                    'source_application': kwargs.get('source_application') or self.client.application_name,
                    'user_id': kwargs.get('user_id'),
                    'chatbot_name': kwargs.get('chatbot_name'),
                    'custom_property': kwargs.get('custom_property'),
                }
                # 清理None值
                context_params = {k: v for k, v in context_params.items() if v is not None}
                return context_manager.start_send_call(
                    target_application=target_application,
                    action=action,
                    **context_params
                )
        else:
            # 使用原有的逻辑，保持向后兼容
            session_id = kwargs.get('session_id') or _session_id_context.get() or str(uuid.uuid4())
            trace_id = kwargs.get('trace_id') or _trace_id_context.get() or self.client.generate_trace_id()
            span_id = kwargs.get('span_id') or _span_id_context.get() or self.client.generate_span_id()
            parent_span_id = kwargs.get('parent_span_id') or _parent_span_id_context.get()
            source_application = kwargs.get('source_application') or _source_application_context.get() or 'unknown'
            user_id = kwargs.get('user_id') or _user_id_context.get()
            chatbot_name = kwargs.get('chatbot_name') or _chatbot_name_context.get()
            custom_property = kwargs.get('custom_property') or _custom_property_context.get()
            
            return {
                'session_id': session_id,
                'trace_id': trace_id,
                'span_id': span_id,
                'parent_span_id': parent_span_id,
                'source_application': source_application,
                'target_application': kwargs.get('target_application'),
                'user_id': user_id,
                'chatbot_name': chatbot_name,
                'custom_property': custom_property
            }
    
    def _set_context(self, **context):
        """
        设置上下文变量
        
        Args:
            **context: 上下文参数
        """
        if not self.use_context_manager:
            # 只有在不使用新上下文管理器时才手动设置上下文变量
            if context.get('session_id'):
                _session_id_context.set(context['session_id'])
            if context.get('trace_id'):
                _trace_id_context.set(context['trace_id'])
            if context.get('span_id'):
                _span_id_context.set(context['span_id'])
            if context.get('parent_span_id'):
                _parent_span_id_context.set(context['parent_span_id'])
            if context.get('source_application'):
                _source_application_context.set(context['source_application'])
            if context.get('user_id'):
                _user_id_context.set(context['user_id'])
            if context.get('chatbot_name'):
                _chatbot_name_context.set(context['chatbot_name'])
            if context.get('custom_property'):
                _custom_property_context.set(context['custom_property'])

    def _clear_context(self):
        """
        清理上下文变量，防止跨请求污染
        """
        if not self.use_context_manager:
            # 只有在不使用新上下文管理器时才手动清理上下文变量
            _session_id_context.set(None)
            _trace_id_context.set(None)
            _span_id_context.set(None)
            _parent_span_id_context.set(None)
            _source_application_context.set(None)
            _user_id_context.set(None)
            _chatbot_name_context.set(None)
            _custom_property_context.set(None)
    
    def _end_context_call(self):
        """
        结束上下文调用
        """
        if self.use_context_manager:
            context_manager = get_global_context_manager()
            context_manager.end_call()
        else:
            self._clear_context()
    
    def _inject_context_to_kwargs(self, kwargs: dict, context: dict) -> dict:
        """
        将上下文注入到函数参数中
        
        Args:
            kwargs: 原始关键字参数
            context: 追踪上下文
            
        Returns:
            注入上下文后的参数字典
        """
        # 创建新的参数字典，避免修改原始参数
        new_kwargs = kwargs.copy()
        
        # 只注入用户函数可能需要的追踪参数，过滤掉内部参数
        allowed_context_keys = {
            'session_id', 'trace_id', 'span_id', 'parent_span_id', 
            'source_application', 'target_application', 'user_id', 'chatbot_name', 'custom_property'
        }
        
        # 注入追踪参数（如果不存在的话）
        # 优先使用原始参数值，不覆盖已存在的参数
        for key, value in context.items():
            if (key in allowed_context_keys and 
                key not in new_kwargs and 
                value is not None):
                new_kwargs[key] = value
                
        return new_kwargs
    

    
    def _add_trace_parameters_to_signature(self, func: Callable) -> Callable:
        """
        向函数签名中添加追踪参数
        
        Args:
            func: 原始函数
            
        Returns:
            具有扩展签名的函数
        """
        # 获取原始函数的签名
        orig_sig = inspect.signature(func)
        params = list(orig_sig.parameters.values())
        param_names = set(p.name for p in params)
        
        # 要添加的追踪参数
        trace_params = {
            'session_id': inspect.Parameter(
                'session_id', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[str]
            ),
            'trace_id': inspect.Parameter(
                'trace_id', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[str]
            ),
            'span_id': inspect.Parameter(
                'span_id', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[str]
            ),
            'parent_span_id': inspect.Parameter(
                'parent_span_id', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[str]
            ),
            'source_application': inspect.Parameter(
                'source_application', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[str]
            ),
            'target_application': inspect.Parameter(
                'target_application', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[str]
            ),
            'user_id': inspect.Parameter(
                'user_id', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[str]
            ),
            'chatbot_name': inspect.Parameter(
                'chatbot_name', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[str]
            ),
            'custom_property': inspect.Parameter(
                'custom_property', inspect.Parameter.KEYWORD_ONLY,
                default=None, annotation=Optional[Dict[str, Any]]
            )
        }
        
        # 添加不存在的参数
        for param_name, param in trace_params.items():
            if param_name not in param_names:
                params.append(param)
        
        # 创建新签名
        new_sig = orig_sig.replace(parameters=params)
        
        # 更新类型注解
        if hasattr(func, '__annotations__'):
            new_annotations = func.__annotations__.copy()
        else:
            new_annotations = {}
        
        trace_annotations = {
            'session_id': Optional[str],
            'trace_id': Optional[str],
            'span_id': Optional[str],
            'parent_span_id': Optional[str],
            'source_application': Optional[str],
            'target_application': Optional[str],
            'user_id': Optional[str],
            'chatbot_name': Optional[str],
            'custom_property': Optional[Dict[str, Any]]
        }
        
        for param_name, annotation in trace_annotations.items():
            if param_name not in new_annotations:
                new_annotations[param_name] = annotation
        
        # 返回签名和注解信息，而不是修改原函数
        return new_sig, new_annotations
    
    def receive_func(
        self,
        *,
        action: Optional[str] = None,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Callable[[F], F]:
        """
        接收端装饰器
        
        记录 receive_request（函数开始时）和 send_response（函数结束时）两个阶段的日志。
        适用于服务器端接收客户端请求的场景。
        
        Args:
            action: 操作名称，默认使用函数名
            tags: 自定义标签
            log_input: 是否记录输入
            log_output: 是否记录输出
            log_errors: 是否记录错误
            output_type: 输出类型 (stream/non-stream)
            auto_inject_context: 是否自动注入上下文到函数参数
            question_field: 指定映射到 input.question 的参数名，如 "user_query" 
            prompt_field: 指定映射到 input.prompt 的参数名，如 "system_prompt"
            document_field: 指定映射到 input.document 的参数名，如 "context_docs"
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
            
        Returns:
            装饰后的函数
            
        Example:
            ```python
            @decorator.receive_func(
                action="process_data",
                question_field="user_query",
                prompt_field="system_prompt",
                document_field="context_docs"
            )
            def process_request(
                user_query: str, 
                system_prompt: str, 
                context_docs: str,
                source_application: str = None  # 动态传入
            ) -> dict:
                # 处理请求
                return {"result": "success"}
            ```
        """
        def decorator(func: F) -> F:
            # 获取扩展的签名和注解
            new_sig, new_annotations = self._add_trace_parameters_to_signature(func)
            
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await self._execute_receive_with_logging(
                    func, args, kwargs,
                    action=action or func.__name__,
                    tags=tags,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    output_type=output_type,
                    auto_inject_context=auto_inject_context,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                return self._execute_receive_sync_with_logging(
                    func, args, kwargs,
                    action=action or func.__name__,
                    tags=tags,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    output_type=output_type,
                    auto_inject_context=auto_inject_context,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            # 根据函数类型选择包装器
            wrapper = async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper
            
            # 应用新签名和注解
            wrapper.__signature__ = new_sig
            wrapper.__annotations__ = new_annotations
            
            return wrapper
        
        return decorator
    
    def send_func(
        self,
        *,
        action: Optional[str] = None,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        auto_span: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Callable[[F], F]:
        """
        发送端装饰器
        
        记录 send_request（函数开始时）和 receive_response（函数结束时）两个阶段的日志。
        适用于客户端调用外部服务的场景。
        
        Args:
            action: 操作名称，默认使用函数名
            tags: 自定义标签
            log_input: 是否记录输入
            log_output: 是否记录输出
            log_errors: 是否记录错误
            output_type: 输出类型 (stream/non-stream)
            auto_inject_context: 是否自动注入上下文到函数参数
            auto_span: 是否自动更新span_id，默认为True。仅在用户没有显式传入span_id时生效
            question_field: 指定映射到 input.question 的参数名，如 "user_query"
            prompt_field: 指定映射到 input.prompt 的参数名，如 "system_prompt"
            document_field: 指定映射到 input.document 的参数名，如 "context_docs"
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
            
        Returns:
            装饰后的函数
            
        Example:
            ```python
            @decorator.send_func(
                action="call_api", 
                question_field="user_query",
                prompt_field="system_prompt"
            )
            def call_external_api(
                user_query: str, 
                system_prompt: str,
                target_application: str = None  # 动态传入
            ) -> dict:
                # 调用外部API
                return {"response": "data"}
            ```
        """
        def decorator(func: F) -> F:
            # 获取扩展的签名和注解
            new_sig, new_annotations = self._add_trace_parameters_to_signature(func)
            
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await self._execute_send_with_logging(
                    func, args, kwargs,
                    action=action or func.__name__,
                    tags=tags,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    output_type=output_type,
                    auto_inject_context=auto_inject_context,
                    auto_span=auto_span,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                return self._execute_send_sync_with_logging(
                    func, args, kwargs,
                    action=action or func.__name__,
                    tags=tags,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    output_type=output_type,
                    auto_inject_context=auto_inject_context,
                    auto_span=auto_span,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            # 根据函数类型选择包装器
            wrapper = async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper
            
            # 应用新签名和注解
            wrapper.__signature__ = new_sig
            wrapper.__annotations__ = new_annotations
            
            return wrapper
        
        return decorator
    
    async def _execute_receive_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        action: str,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """异步执行接收端日志记录"""
        # 快速路径：如果不需要任何日志记录和上下文注入，直接执行函数
        if not log_input and not log_output and not log_errors and not auto_inject_context:
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            if inspect.iscoroutinefunction(func):
                return await func(*args, **filtered_kwargs)
            else:
                return func(*args, **filtered_kwargs)
        
        # 获取或生成追踪上下文
        # 从kwargs中分离出追踪参数，避免传递call_type等内部参数给用户函数
        # 从kwargs中动态获取source_application
        source_application = kwargs.get('source_application')
        
        # 检查是否在工作流上下文中，如果是则继承工作流的追踪参数
        current_workflow_context = _workflow_context.get()
        if current_workflow_context is not None:
            # 在工作流上下文中，优先使用工作流上下文的追踪参数
            trace_kwargs = {
                'session_id': kwargs.get('session_id') or current_workflow_context.get('session_id'),
                'trace_id': kwargs.get('trace_id') or current_workflow_context.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': source_application or current_workflow_context.get('source_application'),
                'user_id': kwargs.get('user_id') or current_workflow_context.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name') or current_workflow_context.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property') or current_workflow_context.get('custom_property'),
            }
        else:
            # 不在工作流上下文中，使用原有逻辑
            trace_kwargs = {
                'session_id': kwargs.get('session_id'),
                'trace_id': kwargs.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': source_application,
                'user_id': kwargs.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property'),
            }
        # 清理None值
        trace_kwargs = {k: v for k, v in trace_kwargs.items() if v is not None}
        
        context = self._get_or_generate_context(
            call_type="receive",
            action=action,
            **trace_kwargs
        )
        
        # 设置上下文变量
        self._set_context(**context)
        
        # 准备标签
        all_tags = ["agent-watch", "receive-func"]
        if tags:
            all_tags.extend(tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            input_data = self._prepare_input_data(
                func, args, kwargs, 
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 记录 receive_request
        if log_input:
            self.client.receive_request(
                session_id=context['session_id'],
                trace_id=context['trace_id'],
                span_id=context['span_id'],
                source_application=source_application or context['source_application'],
                parent_span_id=context.get('parent_span_id'),
                input_data=input_data,
                user_id=context['user_id'],
                chatbot_name=context.get('chatbot_name'),
                action=action,
                tags=all_tags,
                custom_property=context['custom_property']
            )
        
        try:
            # 准备函数参数
            if auto_inject_context:
                # 注入上下文到参数，但只传递原函数实际需要的参数
                injected_kwargs = self._inject_context_to_kwargs(kwargs, context)
                final_kwargs = self._filter_kwargs_for_function(func, args, injected_kwargs)
            else:
                # 移除追踪参数
                final_kwargs = self._filter_trace_params(kwargs, func)
            
            # 执行函数
            if inspect.iscoroutinefunction(func):
                result = await func(*args, **final_kwargs)
            else:
                result = func(*args, **final_kwargs)
            
            # 记录 send_response
            if log_output:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                self.client.send_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=200,
                    target_application=source_application or context['source_application'],
                    parent_span_id=context.get('parent_span_id'),
                    output=output_data,
                    output_type=output_type,
                    first_token_timestamp=first_token_timestamp,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=all_tags,
                    custom_property=context['custom_property']
                )
            
            return result
            
        except Exception as e:
            # 记录错误响应
            if log_errors:
                error_detail = f"{type(e).__name__}: {str(e)}"
                error_tags = all_tags + ["error"]
                
                self.client.send_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=500,
                    target_application=source_application or context['source_application'],
                    parent_span_id=context.get('parent_span_id'),
                    output=error_detail,
                    output_type=output_type,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=error_tags,
                    custom_property=context['custom_property']
                )
            
            raise
        finally:
            # 结束上下文调用
            self._end_context_call()
    
    def _execute_receive_sync_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        action: str,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """同步执行接收端日志记录"""
        # 快速路径：如果不需要任何日志记录和上下文注入，直接执行函数
        if not log_input and not log_output and not log_errors and not auto_inject_context:
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            return func(*args, **filtered_kwargs)
        
        # 获取或生成追踪上下文
        # 从kwargs中分离出追踪参数，避免传递call_type等内部参数给用户函数
        # 从kwargs中动态获取source_application
        source_application = kwargs.get('source_application')
        
        # 检查是否在工作流上下文中，如果是则继承工作流的追踪参数
        current_workflow_context = _workflow_context.get()
        if current_workflow_context is not None:
            # 在工作流上下文中，优先使用工作流上下文的追踪参数
            trace_kwargs = {
                'session_id': kwargs.get('session_id') or current_workflow_context.get('session_id'),
                'trace_id': kwargs.get('trace_id') or current_workflow_context.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': source_application or current_workflow_context.get('source_application'),
                'user_id': kwargs.get('user_id') or current_workflow_context.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name') or current_workflow_context.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property') or current_workflow_context.get('custom_property'),
            }
        else:
            # 不在工作流上下文中，使用原有逻辑
            trace_kwargs = {
                'session_id': kwargs.get('session_id'),
                'trace_id': kwargs.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': source_application,
                'user_id': kwargs.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property'),
            }
        # 清理None值
        trace_kwargs = {k: v for k, v in trace_kwargs.items() if v is not None}
        
        context = self._get_or_generate_context(
            call_type="receive",
            action=action,
            **trace_kwargs
        )
        
        # 设置上下文变量
        self._set_context(**context)
        
        # 准备标签
        all_tags = ["agent-watch", "receive-func"]
        if tags:
            all_tags.extend(tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            input_data = self._prepare_input_data(
                func, args, kwargs, 
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 记录 receive_request
        if log_input:
            self.client.receive_request(
                session_id=context['session_id'],
                trace_id=context['trace_id'],
                span_id=context['span_id'],
                source_application=source_application or context['source_application'],
                parent_span_id=context.get('parent_span_id'),
                input_data=input_data,
                user_id=context['user_id'],
                chatbot_name=context.get('chatbot_name'),
                action=action,
                tags=all_tags,
                custom_property=context['custom_property']
            )
        
        try:
            # 准备函数参数
            if auto_inject_context:
                # 注入上下文到参数，但只传递原函数实际需要的参数
                injected_kwargs = self._inject_context_to_kwargs(kwargs, context)
                final_kwargs = self._filter_kwargs_for_function(func, args, injected_kwargs)
            else:
                # 移除追踪参数
                final_kwargs = self._filter_trace_params(kwargs, func)
            
            # 执行函数
            result = func(*args, **final_kwargs)
            
            # 记录 send_response
            if log_output:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                self.client.send_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=200,
                    target_application=source_application or context['source_application'],
                    parent_span_id=context.get('parent_span_id'),
                    output=output_data,
                    output_type=output_type,
                    first_token_timestamp=first_token_timestamp,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=all_tags,
                    custom_property=context['custom_property']
                )
            
            return result
            
        except Exception as e:
            # 记录错误响应
            if log_errors:
                error_detail = f"{type(e).__name__}: {str(e)}"
                error_tags = all_tags + ["error"]
                
                self.client.send_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=500,
                    target_application=source_application or context['source_application'],
                    parent_span_id=context.get('parent_span_id'),
                    output=error_detail,
                    output_type=output_type,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=error_tags,
                    custom_property=context['custom_property']
                )
            
            raise
        finally:
            # 结束上下文调用
            self._end_context_call()
    
    async def _execute_send_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        action: str,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        auto_span: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """异步执行发送端日志记录"""
        # 快速路径：如果不需要任何日志记录和上下文注入，直接执行函数
        if not log_input and not log_output and not log_errors and not auto_inject_context:
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            if inspect.iscoroutinefunction(func):
                return await func(*args, **filtered_kwargs)
            else:
                return func(*args, **filtered_kwargs)
        
        # 获取或生成追踪上下文
        # 从kwargs中分离出追踪参数，避免传递call_type等内部参数给用户函数
        # 从kwargs中动态获取target_application
        target_application = kwargs.get('target_application')
        
        # 检查是否在工作流上下文中，如果是则继承工作流的追踪参数
        current_workflow_context = _workflow_context.get()
        if current_workflow_context is not None:
            # 在工作流上下文中，优先使用工作流上下文的追踪参数
            trace_kwargs = {
                'session_id': kwargs.get('session_id') or current_workflow_context.get('session_id'),
                'trace_id': kwargs.get('trace_id') or current_workflow_context.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': kwargs.get('source_application') or current_workflow_context.get('source_application'),
                'user_id': kwargs.get('user_id') or current_workflow_context.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name') or current_workflow_context.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property') or current_workflow_context.get('custom_property'),
            }
        else:
            # 不在工作流上下文中，使用原有逻辑
            trace_kwargs = {
                'session_id': kwargs.get('session_id'),
                'trace_id': kwargs.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': kwargs.get('source_application'),
                'user_id': kwargs.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property'),
            }
        # 清理None值
        trace_kwargs = {k: v for k, v in trace_kwargs.items() if v is not None}
        
        context = self._get_or_generate_context(
            call_type="send",
            target_application=target_application,
            action=action,
            **trace_kwargs
        )
        
        # 如果不使用新的上下文管理器，保持原有逻辑
        if not self.use_context_manager:
            # 如果用户没有显式传入 span_id 且 auto_span 为 True，处理 span_id 和 parent_span_id
            if auto_span and 'span_id' not in kwargs:
                # 检查是否在 receive_func 上下文中（通过检查当前上下文变量）
                current_span_id = _span_id_context.get()
                if current_workflow_context is not None:
                    current_span_id = current_span_id or current_workflow_context.get('span_id')
                
                if current_span_id is not None:
                    # 在 receive_func 内部调用：parent_span_id = 旧的 span_id，生成新的 span_id
                    context['parent_span_id'] = current_span_id
                    context['span_id'] = str(uuid.uuid4())
                else:
                    # 独立调用：生成新的 span_id，parent_span_id = 新的 span_id
                    new_span_id = str(uuid.uuid4())
                    context['span_id'] = new_span_id
                    context['parent_span_id'] = new_span_id
        
        # 设置上下文变量
        self._set_context(**context)
        
        # 准备标签
        all_tags = ["agent-watch", "send-func"]
        if tags:
            all_tags.extend(tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            input_data = self._prepare_input_data(
                func, args, kwargs, 
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 记录 send_request 并保存时间戳
        send_timestamp = None
        node_start_time = datetime.now(timezone.utc)
        if log_input:
            send_timestamp = node_start_time
            self.client.send_request(
                session_id=context['session_id'],
                trace_id=context['trace_id'],
                span_id=context['span_id'],
                target_application=target_application or "external",
                parent_span_id=context.get('parent_span_id'),
                input_data=input_data,
                user_id=context['user_id'],
                chatbot_name=context.get('chatbot_name'),
                action=action,
                tags=all_tags,
                custom_property=context['custom_property'],
                send_timestamp=send_timestamp
            )
        
        try:
            # 准备函数参数
            if auto_inject_context:
                # 注入上下文到参数，但只传递原函数实际需要的参数
                injected_kwargs = self._inject_context_to_kwargs(kwargs, context)
                final_kwargs = self._filter_kwargs_for_function(func, args, injected_kwargs)
            else:
                # 移除追踪参数
                final_kwargs = self._filter_trace_params(kwargs, func)
            
            # 执行函数
            if inspect.iscoroutinefunction(func):
                result = await func(*args, **final_kwargs)
            else:
                result = func(*args, **final_kwargs)
            
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 检查是否在工作流上下文中，如果是则将节点信息压入栈中
            current_workflow_stack = _workflow_stack.get()
            if current_workflow_stack is not None:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                # 确定节点类型，根据 target_application 判断
                node_type = self._determine_node_type(target_application or "external")
                
                node_detail = {
                    "sortNo": len(current_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(current_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": node_type,
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "success",
                    "input": input_data or {},
                    "output": {"result": output_data} if output_data else {},
                    "spanId": context['span_id'],
                    "parentSpanId": context.get('parent_span_id'),
                    "tags": all_tags
                }
                
                # 如果有自定义属性，添加到节点详情中
                if context.get('custom_property'):
                    node_detail["customProperty"] = context['custom_property']
                
                current_workflow_stack.append(node_detail)
            
            # 记录 receive_response，传入 send_timestamp
            if log_output:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                self.client.receive_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=200,
                    source_application=target_application or "external",
                    parent_span_id=context.get('parent_span_id'),
                    output=output_data,
                    output_type=output_type,
                    send_timestamp=send_timestamp,
                    first_token_timestamp=first_token_timestamp,
                    user_id=context['user_id'],
                    action=action,
                    tags=all_tags,
                    custom_property=context['custom_property']
                )
            
            return result
            
        except Exception as e:
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 检查是否在工作流上下文中，如果是则将错误节点信息压入栈中
            current_workflow_stack = _workflow_stack.get()
            if current_workflow_stack is not None:
                error_detail = f"{type(e).__name__}: {str(e)}"
                
                # 确定节点类型，根据 target_application 判断
                node_type = self._determine_node_type(target_application or "external")
                
                node_detail = {
                    "sortNo": len(current_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(current_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": node_type,
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "failure",
                    "input": input_data or {},
                    "output": {},
                    "errorMessage": error_detail,
                    "spanId": context['span_id'],
                    "parentSpanId": context.get('parent_span_id'),
                    "tags": all_tags + ["error"]
                }
                
                current_workflow_stack.append(node_detail)
            
            return result
            
        except Exception as e:
            # 记录错误响应，传入 send_timestamp
            if log_errors:
                error_detail = f"{type(e).__name__}: {str(e)}"
                error_tags = all_tags + ["error"]
                
                self.client.receive_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=500,
                    source_application=target_application or "external",
                    parent_span_id=context.get('parent_span_id'),
                    output=error_detail,
                    output_type=output_type,
                    send_timestamp=send_timestamp,
                    result="failed",
                    error_detail=error_detail,
                    user_id=context['user_id'],
                    action=action,
                    tags=error_tags,
                    custom_property=context['custom_property']
                )
            
            raise
        finally:
            # 结束上下文调用
            self._end_context_call()
    
    def _execute_send_sync_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        action: str,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        auto_span: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """同步执行发送端日志记录"""
        # 快速路径：如果不需要任何日志记录和上下文注入，直接执行函数
        if not log_input and not log_output and not log_errors and not auto_inject_context:
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            return func(*args, **filtered_kwargs)
        
        # 获取或生成追踪上下文
        # 从kwargs中分离出追踪参数，避免传递call_type等内部参数给用户函数
        # 从kwargs中动态获取target_application
        target_application = kwargs.get('target_application')
        
        # 检查是否在工作流上下文中，如果是则继承工作流的追踪参数
        current_workflow_context = _workflow_context.get()
        if current_workflow_context is not None:
            # 在工作流上下文中，优先使用工作流上下文的追踪参数
            trace_kwargs = {
                'session_id': kwargs.get('session_id') or current_workflow_context.get('session_id'),
                'trace_id': kwargs.get('trace_id') or current_workflow_context.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': kwargs.get('source_application') or current_workflow_context.get('source_application'),
                'user_id': kwargs.get('user_id') or current_workflow_context.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name') or current_workflow_context.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property') or current_workflow_context.get('custom_property'),
            }
        else:
            # 不在工作流上下文中，使用原有逻辑
            trace_kwargs = {
                'session_id': kwargs.get('session_id'),
                'trace_id': kwargs.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': kwargs.get('source_application'),
                'user_id': kwargs.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property'),
            }
        # 清理None值
        trace_kwargs = {k: v for k, v in trace_kwargs.items() if v is not None}
        
        context = self._get_or_generate_context(
            call_type="send",
            target_application=target_application,
            action=action,
            **trace_kwargs
        )
        
        # 如果不使用新的上下文管理器，保持原有逻辑
        if not self.use_context_manager:
            # 如果用户没有显式传入 span_id 且 auto_span 为 True，处理 span_id 和 parent_span_id
            if auto_span and 'span_id' not in kwargs:
                # 检查是否在 receive_func 上下文中（通过检查当前上下文变量）
                current_span_id = _span_id_context.get()
                if current_workflow_context is not None:
                    current_span_id = current_span_id or current_workflow_context.get('span_id')
                
                if current_span_id is not None:
                    # 在 receive_func 内部调用：parent_span_id = 旧的 span_id，生成新的 span_id
                    context['parent_span_id'] = current_span_id
                    context['span_id'] = str(uuid.uuid4())
                else:
                    # 独立调用：生成新的 span_id，parent_span_id = 新的 span_id
                    new_span_id = str(uuid.uuid4())
                    context['span_id'] = new_span_id
                    context['parent_span_id'] = new_span_id
        
        # 设置上下文变量
        self._set_context(**context)
        
        # 准备标签
        all_tags = ["agent-watch", "send-func"]
        if tags:
            all_tags.extend(tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            input_data = self._prepare_input_data(
                func, args, kwargs, 
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 记录 send_request 并保存时间戳
        send_timestamp = None
        node_start_time = datetime.now(timezone.utc)
        if log_input:
            send_timestamp = node_start_time
            self.client.send_request(
                session_id=context['session_id'],
                trace_id=context['trace_id'],
                span_id=context['span_id'],
                target_application=target_application or "external",
                parent_span_id=context.get('parent_span_id'),
                input_data=input_data,
                user_id=context['user_id'],
                chatbot_name=context.get('chatbot_name'),
                action=action,
                tags=all_tags,
                custom_property=context['custom_property'],
                send_timestamp=send_timestamp
            )
        
        try:
            # 准备函数参数
            if auto_inject_context:
                # 注入上下文到参数，但只传递原函数实际需要的参数
                injected_kwargs = self._inject_context_to_kwargs(kwargs, context)
                final_kwargs = self._filter_kwargs_for_function(func, args, injected_kwargs)
            else:
                # 移除追踪参数
                final_kwargs = self._filter_trace_params(kwargs, func)
            
            # 执行函数
            result = func(*args, **final_kwargs)
            
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 检查是否在工作流上下文中，如果是则将节点信息压入栈中
            current_workflow_stack = _workflow_stack.get()
            if current_workflow_stack is not None:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                # 确定节点类型，根据 target_application 判断
                node_type = self._determine_node_type(target_application or "external")
                
                node_detail = {
                    "sortNo": len(current_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(current_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": node_type,
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "success",
                    "input": input_data or {},
                    "output": {"result": output_data} if output_data else {},
                    "spanId": context['span_id'],
                    "parentSpanId": context.get('parent_span_id'),
                    "tags": all_tags
                }
                
                # 如果有自定义属性，添加到节点详情中
                if context.get('custom_property'):
                    node_detail["customProperty"] = context['custom_property']
                
                current_workflow_stack.append(node_detail)
            
            # 记录 receive_response，传入 send_timestamp
            if log_output:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                self.client.receive_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=200,
                    source_application=target_application or "external",
                    parent_span_id=context.get('parent_span_id'),
                    output=output_data,
                    output_type=output_type,
                    send_timestamp=send_timestamp,
                    first_token_timestamp=first_token_timestamp,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=all_tags,
                    custom_property=context['custom_property']
                )
            
            return result
            
        except Exception as e:
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 检查是否在工作流上下文中，如果是则将错误节点信息压入栈中
            current_workflow_stack = _workflow_stack.get()
            if current_workflow_stack is not None:
                error_detail = f"{type(e).__name__}: {str(e)}"
                
                # 确定节点类型，根据 target_application 判断
                node_type = self._determine_node_type(target_application or "external")
                
                node_detail = {
                    "sortNo": len(current_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(current_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": node_type,
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "failure",
                    "input": input_data or {},
                    "output": {},
                    "errorMessage": error_detail,
                    "spanId": context['span_id'],
                    "parentSpanId": context.get('parent_span_id'),
                    "tags": all_tags + ["error"]
                }
                
                current_workflow_stack.append(node_detail)
            
        except Exception as e:
            # 记录错误响应，传入 send_timestamp
            if log_errors:
                error_detail = f"{type(e).__name__}: {str(e)}"
                error_tags = all_tags + ["error"]
                
                self.client.receive_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=500,
                    source_application=target_application or "external",
                    parent_span_id=context.get('parent_span_id'),
                    output=error_detail,
                    output_type=output_type,
                    send_timestamp=send_timestamp,
                    result="failed",
                    error_detail=error_detail,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=error_tags,
                    custom_property=context['custom_property']
                )
            
            raise
        finally:
            # 结束上下文调用
            self._end_context_call()
    
    async def _execute_node_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        action: str,
        node_type: str = "node",
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """异步执行节点日志记录"""
        # 快速路径：如果不需要任何日志记录和上下文注入，直接执行函数
        if not log_input and not log_output and not log_errors and not auto_inject_context:
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            if inspect.iscoroutinefunction(func):
                return await func(*args, **filtered_kwargs)
            else:
                return func(*args, **filtered_kwargs)
        
        # 检查是否在工作流上下文中
        current_workflow_context = _workflow_context.get()
        current_workflow_stack = _workflow_stack.get()
        
        if current_workflow_context is None:
            # 不在工作流上下文中，直接执行函数
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            if inspect.iscoroutinefunction(func):
                return await func(*args, **filtered_kwargs)
            else:
                return func(*args, **filtered_kwargs)
        
        # 在工作流上下文中，记录节点信息
        # 从kwargs中动态获取source_application
        source_application = kwargs.get('source_application')
        
        # 继承工作流的追踪参数
        trace_kwargs = {
            'session_id': kwargs.get('session_id') or current_workflow_context.get('session_id'),
            'trace_id': kwargs.get('trace_id') or current_workflow_context.get('trace_id'), 
            'span_id': kwargs.get('span_id'),
            'parent_span_id': kwargs.get('parent_span_id'),
            'source_application': source_application or current_workflow_context.get('source_application'),
            'user_id': kwargs.get('user_id') or current_workflow_context.get('user_id'),
            'chatbot_name': kwargs.get('chatbot_name') or current_workflow_context.get('chatbot_name'),
            'custom_property': kwargs.get('custom_property') or current_workflow_context.get('custom_property'),
        }
        # 清理None值
        trace_kwargs = {k: v for k, v in trace_kwargs.items() if v is not None}
        
        context = self._get_or_generate_context(
            call_type="receive",
            action=action,
            **trace_kwargs
        )
        
        # 设置上下文变量
        self._set_context(**context)
        
        # 准备标签
        all_tags = ["agent-watch", "workflow-node", node_type]
        if tags:
            all_tags.extend(tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            input_data = self._prepare_input_data(
                func, args, kwargs, 
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 记录当前节点开始时间
        node_start_time = datetime.now(timezone.utc)
        
        try:
            # 准备函数参数
            if auto_inject_context:
                injected_kwargs = self._inject_context_to_kwargs(kwargs, context)
                final_kwargs = self._filter_kwargs_for_function(func, args, injected_kwargs)
            else:
                final_kwargs = self._filter_trace_params(kwargs, func)
            
            # 执行函数
            if inspect.iscoroutinefunction(func):
                result = await func(*args, **final_kwargs)
            else:
                result = func(*args, **final_kwargs)
            
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 将节点信息压入栈中
            if current_workflow_stack is not None:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                node_detail = {
                    "sortNo": len(current_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(current_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": node_type,
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "success",
                    "input": input_data or {},
                    "output": {"result": output_data} if output_data else {},
                    "tags": all_tags
                }
                
                # 如果有自定义属性，添加到节点详情中
                if context.get('custom_property'):
                    node_detail["customProperty"] = context['custom_property']
                
                current_workflow_stack.append(node_detail)
            
            return result
            
        except Exception as e:
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 将错误节点信息压入栈中
            if current_workflow_stack is not None:
                error_detail = f"{type(e).__name__}: {str(e)}"
                
                node_detail = {
                    "sortNo": len(current_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(current_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": node_type,
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "failure",
                    "input": input_data or {},
                    "output": {},
                    "errorMessage": error_detail,
                    "tags": all_tags + ["error"]
                }
                
                current_workflow_stack.append(node_detail)
            
            raise
        finally:
            # 结束上下文调用
            self._end_context_call()
    
    def _execute_node_sync_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        action: str,
        node_type: str = "node",
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """同步执行节点日志记录"""
        # 快速路径：如果不需要任何日志记录和上下文注入，直接执行函数
        if not log_input and not log_output and not log_errors and not auto_inject_context:
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            return func(*args, **filtered_kwargs)
        
        # 检查是否在工作流上下文中
        current_workflow_context = _workflow_context.get()
        current_workflow_stack = _workflow_stack.get()
        
        if current_workflow_context is None:
            # 不在工作流上下文中，直接执行函数
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            return func(*args, **filtered_kwargs)
        
        # 在工作流上下文中，记录节点信息
        # 从kwargs中动态获取source_application
        source_application = kwargs.get('source_application')
        
        # 继承工作流的追踪参数
        trace_kwargs = {
            'session_id': kwargs.get('session_id') or current_workflow_context.get('session_id'),
            'trace_id': kwargs.get('trace_id') or current_workflow_context.get('trace_id'), 
            'span_id': kwargs.get('span_id'),
            'parent_span_id': kwargs.get('parent_span_id'),
            'source_application': source_application or current_workflow_context.get('source_application'),
            'user_id': kwargs.get('user_id') or current_workflow_context.get('user_id'),
            'chatbot_name': kwargs.get('chatbot_name') or current_workflow_context.get('chatbot_name'),
            'custom_property': kwargs.get('custom_property') or current_workflow_context.get('custom_property'),
        }
        # 清理None值
        trace_kwargs = {k: v for k, v in trace_kwargs.items() if v is not None}
        
        context = self._get_or_generate_context(
            call_type="receive",
            action=action,
            **trace_kwargs
        )
        
        # 设置上下文变量
        self._set_context(**context)
        
        # 准备标签
        all_tags = ["agent-watch", "workflow-node", node_type]
        if tags:
            all_tags.extend(tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            input_data = self._prepare_input_data(
                func, args, kwargs, 
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 记录当前节点开始时间
        node_start_time = datetime.now(timezone.utc)
        
        try:
            # 准备函数参数
            if auto_inject_context:
                injected_kwargs = self._inject_context_to_kwargs(kwargs, context)
                final_kwargs = self._filter_kwargs_for_function(func, args, injected_kwargs)
            else:
                final_kwargs = self._filter_trace_params(kwargs, func)
            
            # 执行函数
            result = func(*args, **final_kwargs)
            
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 将节点信息压入栈中
            if current_workflow_stack is not None:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                node_detail = {
                    "sortNo": len(current_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(current_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": node_type,
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "success",
                    "input": input_data or {},
                    "output": {"result": output_data} if output_data else {},
                    "tags": all_tags
                }
                
                # 如果有自定义属性，添加到节点详情中
                if context.get('custom_property'):
                    node_detail["customProperty"] = context['custom_property']
                
                current_workflow_stack.append(node_detail)
            
            return result
            
        except Exception as e:
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 将错误节点信息压入栈中
            if current_workflow_stack is not None:
                error_detail = f"{type(e).__name__}: {str(e)}"
                
                node_detail = {
                    "sortNo": len(current_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(current_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": node_type,
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "failure",
                    "input": input_data or {},
                    "output": {},
                    "errorMessage": error_detail,
                    "tags": all_tags + ["error"]
                }
                
                current_workflow_stack.append(node_detail)
            
            raise
        finally:
            # 结束上下文调用
            self._end_context_call()
    
    async def _execute_workflow_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        action: str,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """异步执行工作流日志记录"""
        # 快速路径：如果不需要任何日志记录和上下文注入，直接执行函数
        if not log_input and not log_output and not log_errors and not auto_inject_context:
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            if inspect.iscoroutinefunction(func):
                return await func(*args, **filtered_kwargs)
            else:
                return func(*args, **filtered_kwargs)
        
        # 检查是否是最顶层的工作流调用
        current_workflow_context = _workflow_context.get()
        current_workflow_stack = _workflow_stack.get()
        is_top_level = current_workflow_context is None
        
        # 获取或生成追踪上下文
        source_application = kwargs.get('source_application')
        
        # 如果在工作流上下文中，优先使用工作流上下文的 sessionId 和 traceId
        if not is_top_level and current_workflow_context:
            trace_kwargs = {
                'session_id': kwargs.get('session_id') or current_workflow_context.get('session_id'),
                'trace_id': kwargs.get('trace_id') or current_workflow_context.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': source_application or current_workflow_context.get('source_application'),
                'user_id': kwargs.get('user_id') or current_workflow_context.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name') or current_workflow_context.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property') or current_workflow_context.get('custom_property'),
            }
        else:
            trace_kwargs = {
                'session_id': kwargs.get('session_id'),
                'trace_id': kwargs.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': source_application,
                'user_id': kwargs.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property'),
            }
        # 清理None值
        trace_kwargs = {k: v for k, v in trace_kwargs.items() if v is not None}
        
        context = self._get_or_generate_context(
            call_type="receive",
            action=action,
            **trace_kwargs
        )
        
        # 设置上下文变量
        self._set_context(**context)
        
        # 准备标签
        all_tags = ["agent-watch", "workflow"]
        if tags:
            all_tags.extend(tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            input_data = self._prepare_input_data(
                func, args, kwargs, 
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 初始化工作流上下文和栈
        if is_top_level:
            workflow_context = {
                'session_id': context['session_id'],
                'trace_id': context['trace_id'],
                'span_id': context['span_id'],
                'parent_span_id': context.get('parent_span_id'),
                'action': action,
                'start_time': datetime.now(timezone.utc),
                'source_application': source_application or context['source_application'],
                'user_id': context['user_id'],
                'chatbot_name': context.get('chatbot_name'),
                'input_data': input_data,
                'tags': all_tags,
                'custom_property': context['custom_property']
            }
            workflow_stack = []
            _workflow_context.set(workflow_context)
            _workflow_stack.set(workflow_stack)
            
            # 记录工作流的 sendRequest 日志（只有最顶层会发送）
            if log_input:
                self.client.send_request(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    target_application="workflow",
                    parent_span_id=context.get('parent_span_id'),
                    input_data=input_data,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=all_tags,
                    custom_property=context['custom_property']
                )
        else:
            # 子工作流：保存父工作流栈，创建新的独立栈
            parent_workflow_stack = current_workflow_stack
            workflow_stack = []
            _workflow_stack.set(workflow_stack)
        
        # 记录当前节点开始时间
        node_start_time = datetime.now(timezone.utc)
        
        try:
            # 准备函数参数
            if auto_inject_context:
                injected_kwargs = self._inject_context_to_kwargs(kwargs, context)
                final_kwargs = self._filter_kwargs_for_function(func, args, injected_kwargs)
            else:
                final_kwargs = self._filter_trace_params(kwargs, func)
            
            # 执行函数
            if inspect.iscoroutinefunction(func):
                result = await func(*args, **final_kwargs)
            else:
                result = func(*args, **final_kwargs)
            
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 如果不是最顶层，将节点信息压入父工作流栈中
            if not is_top_level and parent_workflow_stack is not None:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                node_detail = {
                    "sortNo": len(parent_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(parent_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": "workflow",
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "success",
                    "input": input_data or {},
                    "output": {"result": output_data} if output_data else {},
                    "tags": all_tags
                }
                
                # 创建子工作流的 customProperty，包含子工作流的 workflowDetail
                subworkflow_custom_property = dict(context.get('custom_property') or {})
                if workflow_stack:
                    subworkflow_custom_property["workflowDetail"] = workflow_stack
                
                # 如果有自定义属性，添加到节点详情中
                if subworkflow_custom_property:
                    node_detail["customProperty"] = subworkflow_custom_property
                
                parent_workflow_stack.append(node_detail)
                
                # 恢复父工作流栈
                _workflow_stack.set(parent_workflow_stack)
            
            # 如果是最顶层，记录 receiveResponse 日志并包含 workflowDetail
            if is_top_level:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                # 构建最终的 customProperty，包含 workflowDetail
                final_custom_property = dict(context.get('custom_property') or {})
                if workflow_stack:
                    final_custom_property["workflowDetail"] = workflow_stack
                
                self.client.receive_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=200,
                    source_application="workflow",
                    parent_span_id=context.get('parent_span_id'),
                    output=output_data,
                    output_type=output_type,
                    first_token_timestamp=first_token_timestamp,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=all_tags,
                    custom_property=final_custom_property if final_custom_property else None
                )
            
            return result
            
        except Exception as e:
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 如果不是最顶层，将错误节点信息压入栈中
            if not is_top_level and workflow_stack is not None:
                error_detail = f"{type(e).__name__}: {str(e)}"
                node_detail = {
                    "sortNo": len(workflow_stack) + 1,
                    "nodeId": f"{action}_{len(workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": "workflow",
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "failure",
                    "input": input_data or {},
                    "output": {},
                    "errorMessage": error_detail,
                    "tags": all_tags + ["error"]
                }
                
                workflow_stack.append(node_detail)
            
            # 如果是最顶层，记录错误的 receiveResponse 日志
            if is_top_level and log_errors:
                error_detail = f"{type(e).__name__}: {str(e)}"
                error_tags = all_tags + ["error"]
                
                # 构建最终的 customProperty，包含 workflowDetail
                final_custom_property = dict(context.get('custom_property') or {})
                if workflow_stack:
                    final_custom_property["workflowDetail"] = workflow_stack
                
                self.client.receive_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=500,
                    source_application="workflow",
                    parent_span_id=context.get('parent_span_id'),
                    output=error_detail,
                    output_type=output_type,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=error_tags,
                    custom_property=final_custom_property if final_custom_property else None
                )
            
            raise
        finally:
            # 如果是最顶层，清理工作流上下文
            if is_top_level:
                _workflow_context.set(None)
                _workflow_stack.set(None)
            
            # 结束上下文调用
            self._end_context_call()
    
    def _execute_workflow_sync_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        action: str,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """同步执行工作流日志记录"""
        # 快速路径：如果不需要任何日志记录和上下文注入，直接执行函数
        if not log_input and not log_output and not log_errors and not auto_inject_context:
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            return func(*args, **filtered_kwargs)
        
        # 检查是否是最顶层的工作流调用
        current_workflow_context = _workflow_context.get()
        current_workflow_stack = _workflow_stack.get()
        is_top_level = current_workflow_context is None
        
        # 获取或生成追踪上下文
        source_application = kwargs.get('source_application')
        
        # 如果在工作流上下文中，优先使用工作流上下文的 sessionId 和 traceId
        if not is_top_level and current_workflow_context:
            trace_kwargs = {
                'session_id': kwargs.get('session_id') or current_workflow_context.get('session_id'),
                'trace_id': kwargs.get('trace_id') or current_workflow_context.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': source_application or current_workflow_context.get('source_application'),
                'user_id': kwargs.get('user_id') or current_workflow_context.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name') or current_workflow_context.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property') or current_workflow_context.get('custom_property'),
            }
        else:
            trace_kwargs = {
                'session_id': kwargs.get('session_id'),
                'trace_id': kwargs.get('trace_id'), 
                'span_id': kwargs.get('span_id'),
                'parent_span_id': kwargs.get('parent_span_id'),
                'source_application': source_application,
                'user_id': kwargs.get('user_id'),
                'chatbot_name': kwargs.get('chatbot_name'),
                'custom_property': kwargs.get('custom_property'),
            }
        # 清理None值
        trace_kwargs = {k: v for k, v in trace_kwargs.items() if v is not None}
        
        context = self._get_or_generate_context(
            call_type="receive",
            action=action,
            **trace_kwargs
        )
        
        # 设置上下文变量
        self._set_context(**context)
        
        # 准备标签
        all_tags = ["agent-watch", "workflow"]
        if tags:
            all_tags.extend(tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            input_data = self._prepare_input_data(
                func, args, kwargs, 
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 初始化工作流上下文和栈
        if is_top_level:
            workflow_context = {
                'session_id': context['session_id'],
                'trace_id': context['trace_id'],
                'span_id': context['span_id'],
                'parent_span_id': context.get('parent_span_id'),
                'action': action,
                'start_time': datetime.now(timezone.utc),
                'source_application': source_application or context['source_application'],
                'user_id': context['user_id'],
                'chatbot_name': context.get('chatbot_name'),
                'input_data': input_data,
                'tags': all_tags,
                'custom_property': context['custom_property']
            }
            workflow_stack = []
            _workflow_context.set(workflow_context)
            _workflow_stack.set(workflow_stack)
            
            # 记录工作流的 sendRequest 日志（只有最顶层会发送）
            if log_input:
                self.client.send_request(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    target_application="workflow",
                    parent_span_id=context.get('parent_span_id'),
                    input_data=input_data,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=all_tags,
                    custom_property=context['custom_property']
                )
        else:
            # 子工作流：保存父工作流栈，创建新的独立栈
            parent_workflow_stack = current_workflow_stack
            workflow_stack = []
            _workflow_stack.set(workflow_stack)
        
        # 记录当前节点开始时间
        node_start_time = datetime.now(timezone.utc)
        
        try:
            # 准备函数参数
            if auto_inject_context:
                injected_kwargs = self._inject_context_to_kwargs(kwargs, context)
                final_kwargs = self._filter_kwargs_for_function(func, args, injected_kwargs)
            else:
                final_kwargs = self._filter_trace_params(kwargs, func)
            
            # 执行函数
            result = func(*args, **final_kwargs)
            
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 如果不是最顶层，将节点信息压入父工作流栈中
            if not is_top_level and parent_workflow_stack is not None:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                node_detail = {
                    "sortNo": len(parent_workflow_stack) + 1,
                    "nodeId": f"{action}_{len(parent_workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": "workflow",
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "success",
                    "input": input_data or {},
                    "output": {"result": output_data} if output_data else {},
                    "tags": all_tags
                }
                
                # 创建子工作流的 customProperty，包含子工作流的 workflowDetail
                subworkflow_custom_property = dict(context.get('custom_property') or {})
                if workflow_stack:
                    subworkflow_custom_property["workflowDetail"] = workflow_stack
                
                # 如果有自定义属性，添加到节点详情中
                if subworkflow_custom_property:
                    node_detail["customProperty"] = subworkflow_custom_property
                
                parent_workflow_stack.append(node_detail)
                
                # 恢复父工作流栈
                _workflow_stack.set(parent_workflow_stack)
            
            # 如果是最顶层，记录 receiveResponse 日志并包含 workflowDetail
            if is_top_level:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                # 构建最终的 customProperty，包含 workflowDetail
                final_custom_property = dict(context.get('custom_property') or {})
                if workflow_stack:
                    final_custom_property["workflowDetail"] = workflow_stack
                
                self.client.receive_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=200,
                    source_application="workflow",
                    parent_span_id=context.get('parent_span_id'),
                    output=output_data,
                    output_type=output_type,
                    first_token_timestamp=first_token_timestamp,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=all_tags,
                    custom_property=final_custom_property if final_custom_property else None
                )
            
            return result
            
        except Exception as e:
            # 记录当前节点结束时间
            node_end_time = datetime.now(timezone.utc)
            execution_time = int((node_end_time - node_start_time).total_seconds() * 1000)
            
            # 如果不是最顶层，将错误节点信息压入栈中
            if not is_top_level and workflow_stack is not None:
                error_detail = f"{type(e).__name__}: {str(e)}"
                node_detail = {
                    "sortNo": len(workflow_stack) + 1,
                    "nodeId": f"{action}_{len(workflow_stack) + 1}",
                    "nodeName": action,
                    "nodeType": "workflow",
                    "startTimestamp": int(node_start_time.timestamp() * 1000),
                    "endTimestamp": int(node_end_time.timestamp() * 1000),
                    "executionTime": execution_time,
                    "executionResult": "failure",
                    "input": input_data or {},
                    "output": {},
                    "errorMessage": error_detail,
                    "tags": all_tags + ["error"]
                }
                
                workflow_stack.append(node_detail)
            
            # 如果是最顶层，记录错误的 receiveResponse 日志
            if is_top_level and log_errors:
                error_detail = f"{type(e).__name__}: {str(e)}"
                error_tags = all_tags + ["error"]
                
                # 构建最终的 customProperty，包含 workflowDetail
                final_custom_property = dict(context.get('custom_property') or {})
                if workflow_stack:
                    final_custom_property["workflowDetail"] = workflow_stack
                
                self.client.receive_response(
                    session_id=context['session_id'],
                    trace_id=context['trace_id'],
                    span_id=context['span_id'],
                    status_code=500,
                    source_application="workflow",
                    parent_span_id=context.get('parent_span_id'),
                    output=error_detail,
                    output_type=output_type,
                    user_id=context['user_id'],
                    chatbot_name=context.get('chatbot_name'),
                    action=action,
                    tags=error_tags,
                    custom_property=final_custom_property if final_custom_property else None
                )
            
            raise
        finally:
            # 如果是最顶层，清理工作流上下文
            if is_top_level:
                _workflow_context.set(None)
                _workflow_stack.set(None)
            
            # 结束上下文调用
            self._end_context_call()
    
    
    def _prepare_input_data(
        self, 
        func: Callable, 
        args: tuple, 
        kwargs: dict,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        准备输入数据，支持字段映射到 input.question, input.prompt, input.document
        
        Args:
            func: 被装饰的函数
            args: 位置参数
            kwargs: 关键字参数
            question_field: 映射到 input.question 的参数名
            prompt_field: 映射到 input.prompt 的参数名 
            document_field: 映射到 input.document 的参数名
            
        Returns:
            格式化的输入数据字典
        """
        try:
            # 获取函数签名
            signature = inspect.signature(func)
            
            # 先过滤掉追踪参数，只使用原始函数需要的参数
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            
            # 绑定所有参数
            bound_args = signature.bind(*args, **filtered_kwargs)
            bound_args.apply_defaults()
            
            all_arguments = dict(bound_args.arguments)
            
            # 如果没有指定任何字段映射，使用默认行为
            if not question_field and not prompt_field and not document_field:
                # 默认行为：将所有参数转换为 JSON 字符串，放到 input.question 字段
                import json
                try:
                    question_value = json.dumps(all_arguments, ensure_ascii=False, default=str)
                except Exception:
                    question_value = str(all_arguments)
                
                return {
                    "question": question_value
                }
            
            # 使用字段映射
            input_data = {}
            
            # 映射 question 字段
            if question_field and question_field in all_arguments:
                input_data["question"] = str(all_arguments[question_field])
            
            # 映射 prompt 字段
            if prompt_field and prompt_field in all_arguments:
                input_data["prompt"] = str(all_arguments[prompt_field])
            
            # 映射 document 字段
            if document_field and document_field in all_arguments:
                input_data["document"] = str(all_arguments[document_field])
            
            # 如果指定了字段映射但都没有找到对应的参数，回退到默认行为
            if not input_data:
                import json
                try:
                    question_value = json.dumps(all_arguments, ensure_ascii=False, default=str)
                except Exception:
                    question_value = str(all_arguments)
                
                input_data["question"] = question_value
            
            return input_data
            
        except Exception as e:
            print(f"Failed to capture input data: {e}")
            # 如果处理失败，使用简化的参数记录
            filtered_kwargs = self._filter_trace_params(kwargs, func)
            import json
            try:
                question_value = json.dumps({
                    "args_count": len(args), 
                    "kwargs": filtered_kwargs
                }, ensure_ascii=False, default=str)
            except Exception:
                question_value = f"args_count: {len(args)}, kwargs: {filtered_kwargs}"
            
            return {"question": question_value}
    
    def _prepare_output_data(
        self, 
        result: Any, 
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> tuple[str, Optional[datetime]]:
        """
        准备输出数据，支持字段映射到 output 和 first_token_timestamp
        
        Args:
            result: 函数返回结果
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
            
        Returns:
            元组：(output_data, first_token_timestamp)
        """
        import json
        output_data = None
        first_token_timestamp = None
        
        try:
            if result is not None:
                # 如果指定了字段映射
                if output_field or ft_field:
                    # 处理字典类型结果
                    if isinstance(result, dict):
                        if output_field and output_field in result:
                            field_value = result[output_field]
                            # 对于字符串类型，直接返回原始值
                            if isinstance(field_value, str):
                                output_data = field_value
                            else:
                                # 对于其他类型，使用 JSON 格式
                                try:
                                    output_data = json.dumps(field_value, ensure_ascii=False, default=str)
                                except Exception:
                                    output_data = str(field_value)
                        
                        if ft_field and ft_field in result:
                            ft_value = result[ft_field]
                            # 尝试解析时间戳
                            if isinstance(ft_value, datetime):
                                first_token_timestamp = ft_value
                            elif isinstance(ft_value, (int, float)):
                                first_token_timestamp = datetime.fromtimestamp(ft_value, timezone.utc)
                            elif isinstance(ft_value, str):
                                try:
                                    # 尝试解析ISO格式时间字符串
                                    first_token_timestamp = datetime.fromisoformat(ft_value.replace('Z', '+00:00'))
                                except ValueError:
                                    try:
                                        # 尝试解析时间戳字符串
                                        first_token_timestamp = datetime.fromtimestamp(float(ft_value), timezone.utc)
                                    except ValueError:
                                        pass
                
                # 如果没有通过字段映射获取到输出数据，使用默认行为（JSON格式，不限制长度）
                if output_data is None:
                    # 对于字符串类型，直接返回原始值
                    if isinstance(result, str):
                        output_data = result
                    else:
                        # 对于其他类型，使用 JSON 格式
                        try:
                            output_data = json.dumps(result, ensure_ascii=False, default=str)
                        except Exception:
                            output_data = str(result)
                    
        except Exception:
            output_data = f"<{type(result).__name__} object>"
        
        return output_data, first_token_timestamp
    
    def _filter_kwargs_for_function(self, func: Callable, args: tuple, kwargs: dict) -> dict:
        """
        过滤参数，只保留函数实际接受的参数，避免参数冲突
        
        Args:
            func: 目标函数
            args: 位置参数
            kwargs: 参数字典
            
        Returns:
            过滤后的参数字典
        """
        try:
            # 获取函数签名
            sig = inspect.signature(func)
            
            # 先获取原始参数（非追踪参数）
            original_kwargs = self._filter_trace_params(kwargs, func)
            
            # 绑定位置参数以确定哪些参数已经被占用
            try:
                bound_args = sig.bind_partial(*args, **original_kwargs)
                bound_param_names = set(bound_args.arguments.keys())
            except Exception:
                # 如果绑定失败，假设没有绑定
                bound_param_names = set()
            
            # 然后获取注入的上下文参数
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'target_application', 'headers', 'user_id', 'chatbot_name', 'custom_property'
            }
            context_kwargs = {k: v for k, v in kwargs.items() if k in trace_param_names}
            
            # 构建最终参数：先添加原始参数
            final_kwargs = original_kwargs.copy()
            
            # 然后添加上下文参数，但只在函数签名中存在且没有被位置参数或原始关键字参数占用的情况下
            param_names = set(sig.parameters.keys())
            for key, value in context_kwargs.items():
                if (key in param_names and 
                    key not in bound_param_names and 
                    key not in original_kwargs and 
                    value is not None):
                    final_kwargs[key] = value
            
            return final_kwargs
        except Exception:
            # 如果无法获取签名，默认移除追踪参数
            return self._filter_trace_params(kwargs, func)
    
    def _filter_trace_params(self, kwargs: dict, func: Optional[Callable] = None) -> dict:
        """
        过滤追踪参数，但保留原始函数签名中存在的追踪参数
        
        Args:
            kwargs: 参数字典
            func: 目标函数，如果提供则会检查函数签名来保留需要的追踪参数
            
        Returns:
            过滤后的参数字典
        """
        trace_param_names = {
            'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
            'target_application', 'headers', 'user_id', 'chatbot_name', 'custom_property'
        }
        
        if func is None:
            # 如果没有提供函数，使用原有逻辑（完全过滤掉追踪参数）
            return {k: v for k, v in kwargs.items() if k not in trace_param_names}
        
        try:
            # 获取函数签名中的参数名
            sig = inspect.signature(func)
            func_param_names = set(sig.parameters.keys())
            
            # 保留非追踪参数和函数签名中存在的追踪参数
            filtered_kwargs = {}
            for k, v in kwargs.items():
                if k not in trace_param_names:
                    # 非追踪参数，直接保留
                    filtered_kwargs[k] = v
                elif k in func_param_names:
                    # 追踪参数但在函数签名中存在，保留
                    filtered_kwargs[k] = v
                # 追踪参数且不在函数签名中，过滤掉
            
            return filtered_kwargs
            
        except Exception:
            # 如果无法获取函数签名，使用原有逻辑
            return {k: v for k, v in kwargs.items() if k not in trace_param_names}
    
    def set_context(
        self,
        session_id: Optional[str] = None,
        trace_id: Optional[str] = None,
        span_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        source_application: Optional[str] = None,
        user_id: Optional[str] = None,
        chatbot_name: Optional[str] = None,
        custom_property: Optional[Dict[str, Any]] = None
    ):
        """
        手动设置追踪上下文
        
        Args:
            session_id: 会话ID
            trace_id: 追踪ID
            span_id: 跨度ID
            parent_span_id: 父跨度ID
            source_application: 来源应用
            user_id: 用户ID
            chatbot_name: 聊天机器人名称
            custom_property: 自定义属性
        """
        context = {}
        if session_id is not None:
            context['session_id'] = session_id
        if trace_id is not None:
            context['trace_id'] = trace_id
        if span_id is not None:
            context['span_id'] = span_id
        if parent_span_id is not None:
            context['parent_span_id'] = parent_span_id
        if source_application is not None:
            context['source_application'] = source_application
        if user_id is not None:
            context['user_id'] = user_id
        if chatbot_name is not None:
            context['chatbot_name'] = chatbot_name
        if custom_property is not None:
            context['custom_property'] = custom_property
        
        self._set_context(**context)
    
    def get_context(self) -> Dict[str, Any]:
        """
        获取当前追踪上下文
        
        Returns:
            当前的追踪上下文字典
        """
        return {
            'session_id': _session_id_context.get(),
            'trace_id': _trace_id_context.get(),
            'span_id': _span_id_context.get(),
            'parent_span_id': _parent_span_id_context.get(),
            'source_application': _source_application_context.get(),
            'user_id': _user_id_context.get(),
            'chatbot_name': _chatbot_name_context.get(),
            'custom_property': _custom_property_context.get()
        }
    
    def _determine_node_type(self, target_application: str) -> str:
        """
        根据 target_application 确定节点类型
        
        Args:
            target_application: 目标应用名称
            
        Returns:
            节点类型字符串
        """
        # 根据文档中的节点类型定义
        if target_application.lower() in ['plugin', 'plugins']:
            return "plugin"
        elif target_application.lower() in ['kmverse', 'knowledgebase', 'knowledge_base']:
            return "knowledgeBase"
        elif target_application.lower() in ['aiverse', 'llm', 'ai']:
            return "llm"
        elif target_application.lower() in ['workflow', 'subworkflow']:
            return "subworkflow"
        else:
            return "external"
    
    def node(
        self,
        *,
        action: Optional[str] = None,
        node_type: str = "node",
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Callable[[F], F]:
        """
        工作流节点装饰器
        
        标记工作流里的子节点，按照工作流日志要求把日志压入一个栈中。
        
        Args:
            action: 操作名称，默认使用函数名
            node_type: 节点类型，如 "plugin", "knowledgeBase", "llm", "node" 等
            tags: 自定义标签
            log_input: 是否记录输入
            log_output: 是否记录输出
            log_errors: 是否记录错误
            output_type: 输出类型 (stream/non-stream)
            auto_inject_context: 是否自动注入上下文到函数参数
            question_field: 指定映射到 input.question 的参数名
            prompt_field: 指定映射到 input.prompt 的参数名
            document_field: 指定映射到 input.document 的参数名
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
            
        Returns:
            装饰后的函数
        """
        def decorator(func: F) -> F:
            # 获取扩展的签名和注解
            new_sig, new_annotations = self._add_trace_parameters_to_signature(func)
            
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await self._execute_node_with_logging(
                    func, args, kwargs,
                    action=action or func.__name__,
                    node_type=node_type,
                    tags=tags,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    output_type=output_type,
                    auto_inject_context=auto_inject_context,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                return self._execute_node_sync_with_logging(
                    func, args, kwargs,
                    action=action or func.__name__,
                    node_type=node_type,
                    tags=tags,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    output_type=output_type,
                    auto_inject_context=auto_inject_context,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            # 根据函数类型选择包装器
            wrapper = async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper
            
            # 应用新签名和注解
            wrapper.__signature__ = new_sig
            wrapper.__annotations__ = new_annotations
            
            return wrapper
        
        return decorator
    
    def workflow(
        self,
        *,
        action: Optional[str] = None,
        tags: Optional[List[str]] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        output_type: str = "non-stream",
        auto_inject_context: bool = True,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Callable[[F], F]:
        """
        工作流装饰器
        
        根据文档要求实现工作流日志功能：
        - 最顶层的方法记录工作流的 sendRequest 与 receiveResponse 日志，只有最顶层会发送日志
        - 中间层级方法按照工作流日志要求把日志压入一个栈中  
        - 如果调用层级里有 send_request 装饰的方法，除了正常发送日志之外也要按照工作流日志要求把日志压入一个栈中
        - 最后把栈里的日志输出在 workflow 的 stage = receiveResponse 的 customProperty.workflowDetail 里
        
        Args:
            action: 操作名称，默认使用函数名
            tags: 自定义标签
            log_input: 是否记录输入
            log_output: 是否记录输出
            log_errors: 是否记录错误
            output_type: 输出类型 (stream/non-stream)
            auto_inject_context: 是否自动注入上下文到函数参数
            question_field: 指定映射到 input.question 的参数名
            prompt_field: 指定映射到 input.prompt 的参数名
            document_field: 指定映射到 input.document 的参数名
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
            
        Returns:
            装饰后的函数
        """
        def decorator(func: F) -> F:
            # 获取扩展的签名和注解
            new_sig, new_annotations = self._add_trace_parameters_to_signature(func)
            
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await self._execute_workflow_with_logging(
                    func, args, kwargs,
                    action=action or func.__name__,
                    tags=tags,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    output_type=output_type,
                    auto_inject_context=auto_inject_context,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                return self._execute_workflow_sync_with_logging(
                    func, args, kwargs,
                    action=action or func.__name__,
                    tags=tags,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    output_type=output_type,
                    auto_inject_context=auto_inject_context,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            # 根据函数类型选择包装器
            wrapper = async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper
            
            # 应用新签名和注解
            wrapper.__signature__ = new_sig
            wrapper.__annotations__ = new_annotations
            
            return wrapper
        
        return decorator


def create_agent_watch_decorator(
    collector_url: str,
    application_name: str,
    use_context_manager: bool = False,
    **kwargs
) -> AgentWatchDecorator:
    """
    便捷函数：创建 Agent Watch 装饰器
    
    Args:
        collector_url: Agent Watch Collector URL
        application_name: 应用名称
        use_context_manager: 是否使用新的上下文管理器，确保调用链路ID正确管理 (默认: False)
        verify_ssl: 是否验证SSL证书 (默认: True)
        ca_bundle: CA证书包路径 (可选)
        **kwargs: 其他认证和配置参数
    
    Returns:
        AgentWatchDecorator 实例
        
    Example:
        ```python
        # 创建装饰器 (使用新的上下文管理器)
        decorator = create_agent_watch_decorator(
            collector_url="https://collector.example.com",
            application_name="myApp",
            auth_type="fixed_token",
            use_context_manager=True  # 启用新的上下文管理器
        )
        
        # 使用接收端装饰器
        @decorator.receive_func(action="process_data")
        def process_request(data: dict, chatbot_name: str = "myBot") -> dict:
            # chatbot_name 现在是函数参数，而不是装饰器参数
            return {"result": "processed"}
        
        # 使用发送端装饰器
        @decorator.send_func(action="call_api", target_application="external_api")
        def call_external_api(params: dict, chatbot_name: str = "myBot") -> dict:
            # chatbot_name 现在是函数参数，而不是装饰器参数
            return {"response": "data"}
        ```
    """
    client = AgentWatchClient(
        collector_url=collector_url,
        application_name=application_name,
        **kwargs
    )
    return AgentWatchDecorator(client, use_context_manager=use_context_manager)


# 全局装饰器实例
_global_decorator: Optional[AgentWatchDecorator] = None


def setup_global_decorator(
    collector_url: str,
    application_name: str,
    use_context_manager: bool = False,
    **auth_kwargs
) -> AgentWatchDecorator:
    """
    设置全局 Agent Watch 装饰器实例
    
    Args:
        collector_url: Agent Watch Collector URL
        application_name: 应用名称
        use_context_manager: 是否使用新的上下文管理器 (默认: False)
        **auth_kwargs: 认证参数
    
    Returns:
        AgentWatchDecorator 实例
    """
    global _global_decorator
    _global_decorator = create_agent_watch_decorator(
        collector_url=collector_url,
        application_name=application_name,
        use_context_manager=use_context_manager,
        **auth_kwargs
    )
    return _global_decorator


def get_global_decorator() -> AgentWatchDecorator:
    """
    获取全局装饰器实例
    
    Returns:
        全局 AgentWatchDecorator 实例
        
    Raises:
        RuntimeError: 如果未设置全局装饰器
    """
    if _global_decorator is None:
        raise RuntimeError(
            "Global AgentWatch decorator not initialized. "
            "Call setup_global_decorator() first."
        )
    return _global_decorator


def receive_func(**kwargs) -> Callable[[F], F]:
    """
    全局接收端装饰器
    
    使用前需先调用 setup_global_decorator() 设置全局实例。
    """
    return get_global_decorator().receive_func(**kwargs)


def send_func(**kwargs) -> Callable[[F], F]:
    """
    全局发送端装饰器
    
    使用前需先调用 setup_global_decorator() 设置全局实例。
    """
    return get_global_decorator().send_func(**kwargs)


def set_context(**kwargs):
    """
    设置全局追踪上下文
    
    使用前需先调用 setup_global_decorator() 设置全局实例。
    """
    get_global_decorator().set_context(**kwargs)


def get_context() -> Dict[str, Any]:
    """
    获取全局追踪上下文
    
    使用前需先调用 setup_global_decorator() 设置全局实例。
    """
    return get_global_decorator().get_context()


def node(**kwargs) -> Callable[[F], F]:
    """
    全局工作流节点装饰器
    
    使用前需先调用 setup_global_decorator() 设置全局实例。
    """
    return get_global_decorator().node(**kwargs)


def workflow(**kwargs) -> Callable[[F], F]:
    """
    全局工作流装饰器
    
    使用前需先调用 setup_global_decorator() 设置全局实例。
    """
    return get_global_decorator().workflow(**kwargs)
