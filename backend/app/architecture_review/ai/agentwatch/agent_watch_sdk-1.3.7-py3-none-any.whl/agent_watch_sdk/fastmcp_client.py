import asyncio
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional, List, Union
from fastmcp import Client as FastMCPClient
from fastmcp.client.progress import ProgressHandler
import datetime as dt
import mcp.types

from .client import AgentWatchClient
from .models import LogStage
from .auth import OAuth2Client, create_auth_client


class AgentWatchFastMCPClient(FastMCPClient):
    """
    扩展的 FastMCP Client，集成 AgentWatch 日志功能
    
    在调用工具时自动发送 send_request 和 receive_response 阶段的日志，
    让用户无感知地进行链路追踪。
    """
    
    def __init__(self, 
                 transport,
                 # AgentWatch 配置
                 collector_url: str,
                 application_name: str,
                 # 认证配置 (支持 AgentWatchClient 的所有认证选项)
                 auth_client=None,
                 client_id: Optional[str] = None,
                 client_secret: Optional[str] = None,
                 token_url: Optional[str] = None,
                 auth_type: str = "oauth2",
                 verify_ssl: bool = True,
                 # FastMCP Client 原有配置
                 **fastmcp_kwargs):
        """
        初始化 AgentWatchFastMCPClient
        
        Args:
            transport: FastMCP 的传输层配置或URL
            collector_url: AgentWatch Collector URL
            application_name: 当前应用名称
            auth_client: 预配置的认证客户端
            client_id: OAuth2 客户端ID (向后兼容)
            client_secret: OAuth2 客户端密钥 (向后兼容)
            token_url: OAuth2 令牌URL (向后兼容)
            auth_type: 认证类型 ('oauth2', 'fixed_token', 'none')
            **fastmcp_kwargs: FastMCP Client 的其他参数
        """
        # 收集所有认证相关参数，在传递给 FastMCP 之前移除
        auth_related_keys = ['client_id', 'client_secret', 'token_url', 'token_env_var', 
                           'fixed_token_header_key', 'custom_headers_env_var',
                           'username', 'password', 'api_key', 'require_both', 'require_all',
                           'oauth2_header_key', 'auth_configs', 'auth_clients', 'chatbot_name','verify_ssl']
        
        auth_params = {}
        filtered_fastmcp_kwargs = {}
        
        # 首先添加明确的参数
        if client_id is not None:
            auth_params['client_id'] = client_id
        if client_secret is not None:
            auth_params['client_secret'] = client_secret 
        if token_url is not None:
            auth_params['token_url'] = token_url
        
        # 然后处理 fastmcp_kwargs
        for key, value in fastmcp_kwargs.items():
            if key.startswith('auth_') or key in auth_related_keys:
                auth_params[key] = value
            else:
                filtered_fastmcp_kwargs[key] = value
        
        # 初始化 FastMCP Client（只传递非认证相关的参数）
        super().__init__(transport, **filtered_fastmcp_kwargs)
        
        # 初始化 AgentWatch Client
        agent_watch_kwargs = {}
        if auth_client:
            agent_watch_kwargs['auth_client'] = auth_client
        elif client_id and client_secret and token_url:
            # 向后兼容：从单独参数创建 OAuth2 客户端
            agent_watch_kwargs['auth_client'] = OAuth2Client(client_id, client_secret, token_url)
        else:
            # 基于 auth_type 创建认证客户端
            
            if auth_type == "oauth2":
                required_oauth_params = ["client_id", "client_secret", "token_url"]
                if not all(auth_params.get(param) for param in required_oauth_params):
                    raise ValueError("OAuth2 authentication requires client_id, client_secret, and token_url")
            
            agent_watch_kwargs['auth_client'] = create_auth_client(auth_type,verify_ssl=verify_ssl, **auth_params)
        
        self.agent_watch = AgentWatchClient(
            collector_url=collector_url,
            application_name=application_name,
            verify_ssl=verify_ssl,
            **agent_watch_kwargs
        )
        
        # 存储应用信息
        self.application_name = application_name
        
        # 当前会话和追踪信息
        self._current_session_id: Optional[str] = None
        self._current_trace_id: Optional[str] = None
        self._current_user_id: Optional[str] = None
    
    def set_trace_context(self, 
                         session_id: Optional[str] = None,
                         trace_id: Optional[str] = None, 
                         user_id: Optional[str] = None):
        """
        设置追踪上下文信息
        
        Args:
            session_id: 会话ID，如不提供则自动生成
            trace_id: 追踪ID，如不提供则自动生成  
            user_id: 用户ID
        """
        self._current_session_id = session_id or str(uuid.uuid4())
        self._current_trace_id = trace_id or str(uuid.uuid4())
        self._current_user_id = user_id
    
    def _ensure_trace_context(self):
        """确保追踪上下文存在"""
        if not self._current_session_id:
            self._current_session_id = str(uuid.uuid4())
        if not self._current_trace_id:
            self._current_trace_id = str(uuid.uuid4())
    
    def _get_server_name(self) -> str:
        """获取当前连接的服务器名称"""
        try:
            # 尝试从 initialize_result 获取服务器名称
            if hasattr(self, '_initialize_result') and self._initialize_result:
                server_info = getattr(self._initialize_result, 'serverInfo', None)
                if server_info and hasattr(server_info, 'name'):
                    return server_info.name
            
            # 如果从 transport 可以获取到服务器名称
            if hasattr(self.transport, 'server') and hasattr(self.transport.server, 'name'):
                return self.transport.server.name
                
            # 如果是 URL 连接，尝试从 URL 推断
            if hasattr(self.transport, 'url'):
                url = self.transport.url
                if isinstance(url, str):
                    # 简单的推断：从 URL 路径或主机名获取
                    from urllib.parse import urlparse
                    parsed = urlparse(url)
                    if parsed.path and parsed.path != '/' and parsed.path != '/mcp':
                        # 去掉前导斜杠和 mcp 路径
                        path_parts = [p for p in parsed.path.split('/') if p and p != 'mcp']
                        if path_parts:
                            return path_parts[0]
                    # 使用主机名
                    if parsed.hostname:
                        return parsed.hostname
                        
        except Exception as e:
            # 日志记录异常但不影响主要功能
            print(f"Warning: Failed to get server name: {e}")
        
        # 如果所有方法都失败，返回默认值
        return "mcp-server"
    
    async def call_tool(self,
                       name: str,
                       arguments: dict[str, Any] | None = None,
                       timeout: dt.timedelta | float | int | None = None,
                       progress_handler: ProgressHandler | None = None,
                       raise_on_error: bool = True,  # 我们自己处理这个参数
                       # AgentWatch 扩展参数
                       session_id: Optional[str] = None,
                       trace_id: Optional[str] = None,
                       span_id: Optional[str] = None,
                       parent_span_id: Optional[str] = None,
                       user_id: Optional[str] = None,
                       chatbot_name: Optional[str] = None,
                       action: Optional[str] = None,
                       tags: Optional[List[str]] = None,
                       custom_property: Optional[Dict[str, Any]] = None,
                       target_application: Optional[str] = None,
                       # 字段映射参数
                       question_field: Optional[str] = None,
                       prompt_field: Optional[str] = None,
                       document_field: Optional[str] = None,
                       output_field: Optional[str] = None,
                       ft_field: Optional[str] = None) -> Any:
        """
        调用工具，自动记录 send_request 和 receive_response 日志
        
        Args:
            name: 工具名称
            arguments: 工具参数
            timeout: 超时时间
            progress_handler: 进度处理器
            raise_on_error: 是否在错误时抛出异常
            session_id: 会话ID (可选，不提供则使用上下文中的)
            trace_id: 追踪ID (可选，不提供则使用上下文中的)
            user_id: 用户ID (可选，不提供则使用上下文中的)
            chatbot_name: 聊天机器人名称 (可选)
            action: 操作名称 (可选，默认为工具名称)
            tags: 标签列表 (可选)
            custom_property: 自定义属性 (可选)
            target_application: 目标应用名称 (可选，默认为 'mcp-server')
            question_field: 指定映射到 input.question 的参数名
            prompt_field: 指定映射到 input.prompt 的参数名
            document_field: 指定映射到 input.document 的参数名
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
            
        Returns:
            CallToolResult: 工具调用结果
        """
        # 使用提供的追踪信息或当前上下文
        current_session_id = session_id or self._current_session_id
        current_trace_id = trace_id or self._current_trace_id
        current_user_id = user_id or self._current_user_id
        
        # 确保有追踪上下文
        if not current_session_id or not current_trace_id:
            self._ensure_trace_context()
            current_session_id = current_session_id or self._current_session_id  
            current_trace_id = current_trace_id or self._current_trace_id
        
        # 实现 span_id/parent_span_id 逻辑
        if span_id and parent_span_id:
            # 如果同时提供了 span_id 和 parent_span_id，使用用户提供的
            final_span_id = span_id
            final_parent_span_id = parent_span_id
        elif parent_span_id and not span_id:
            # 如果只提供了 parent_span_id，生成新的 span_id
            final_span_id = str(uuid.uuid4())
            final_parent_span_id = parent_span_id
        elif span_id and not parent_span_id:
            # 如果只提供了 span_id，设置 parent_span_id = span_id
            final_span_id = span_id
            final_parent_span_id = span_id
        else:
            # 如果都没有提供，生成新的 span_id，parent_span_id 为 None
            final_span_id = str(uuid.uuid4())
            final_parent_span_id = None
        
        # 默认值
        if not action:
            action = f"call_tool_{name}"
        if not target_application:
            # 尝试从连接的服务器获取名称
            target_application = self._get_server_name()
        
        # 记录发送请求日志
        send_timestamp = datetime.now(timezone.utc)
        try:
            # 准备输入数据，使用字段映射
            input_data = self._prepare_input_data(
                arguments or {},
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
            
            self.agent_watch.send_request(
                session_id=current_session_id,
                trace_id=current_trace_id,
                span_id=final_span_id,
                target_application=target_application,
                input_data=input_data,
                user_id=current_user_id,
                chatbot_name=chatbot_name,
                send_timestamp=send_timestamp,
                action=action,
                tags=tags,
                custom_property=custom_property
            )
        except Exception as e:
            # 日志发送失败不应影响主要功能
            print(f"Warning: Failed to send request log: {e}")
        
        # 将追踪信息添加到 arguments 中发送给服务端
        enhanced_arguments = (arguments or {}).copy()
        
        # 只添加核心追踪参数，避免与工具参数冲突
        trace_params = {
            'session_id': current_session_id,
            'trace_id': current_trace_id,
            'span_id': final_span_id,
            'source_application': self.application_name,
            'chatbot_name': chatbot_name
        }
        
        # 如果有 parent_span_id，也添加进去
        if final_parent_span_id is not None:
            trace_params['parent_span_id'] = final_parent_span_id
        
        # 如果有用户ID，也添加进去
        if current_user_id:
            trace_params['user_id'] = current_user_id
        
        # 只有当原参数中没有这些键时才添加，避免覆盖用户的参数
        for key, value in trace_params.items():
            if key not in enhanced_arguments:
                enhanced_arguments[key] = value
        
        # 调用原始的 call_tool 方法
        result = None
        error_occurred = False
        error_detail = None
        
        try:
            # 直接调用 call_tool_mcp 来避免重复记录日志
            # 因为 fastmcp 的 call_tool 内部会调用 call_tool_mcp，会导致重复记录
            mcp_result = await super().call_tool_mcp(
                name=name,
                arguments=enhanced_arguments,
                timeout=timeout,
                progress_handler=progress_handler
            )
            
            # 按照 fastmcp 2.8.0 的行为直接返回 content
            if mcp_result.isError and raise_on_error:
                from fastmcp.exceptions import ToolError
                msg = mcp_result.content[0].text if mcp_result.content else "Tool call failed"
                raise ToolError(msg)
            
            # fastmcp 2.8.0 的 call_tool 方法直接返回 content 列表
            result = mcp_result.content
            
        except Exception as e:
            error_occurred = True
            error_detail = str(e)
            if raise_on_error:
                # 先记录 receive_response 日志，再重新抛出异常
                try:
                    self.agent_watch.receive_response(
                        session_id=current_session_id,
                        trace_id=current_trace_id,
                        span_id=final_span_id,
                        status_code=500,
                        source_application=target_application,
                        parent_span_id=final_parent_span_id,
                        output=None,
                        send_timestamp=send_timestamp,
                        result="failed",
                        error_detail=error_detail,
                        user_id=current_user_id,
                        chatbot_name=chatbot_name,
                        action=action,
                        tags=tags,
                        custom_property=custom_property
                    )
                except Exception as log_error:
                    print(f"Warning: Failed to send error response log: {log_error}")
                raise e
            else:
                # 不抛出异常的情况下，返回 None 表示错误
                result = None
        
        # 记录接收响应日志
        try:
            status_code = 500 if error_occurred else 200
            result_status = "failed" if error_occurred else "succeed"
            
            # 提取输出内容和时间戳
            output_content = None
            first_token_timestamp = None
            
            if result and not error_occurred:
                output_content, first_token_timestamp = self._prepare_output_data(
                    result, 
                    output_field=output_field, 
                    ft_field=ft_field
                )
            
            self.agent_watch.receive_response(
                session_id=current_session_id,
                trace_id=current_trace_id,
                span_id=final_span_id,
                status_code=status_code,
                source_application=target_application,
                parent_span_id=final_parent_span_id,
                output=output_content,
                send_timestamp=send_timestamp,
                result=result_status,
                error_detail=error_detail,
                user_id=current_user_id,
                chatbot_name=chatbot_name,
                action=action,
                tags=tags,
                custom_property=custom_property,
                first_token_timestamp=first_token_timestamp
            )
        except Exception as e:
            # 日志发送失败不应影响主要功能
            print(f"Warning: Failed to send response log: {e}")
        
        return result
    
    async def call_tool_mcp(self,
                           name: str,
                           arguments: dict[str, Any],
                           progress_handler: ProgressHandler | None = None,
                           timeout: dt.timedelta | float | int | None = None,
                           # AgentWatch 扩展参数  
                           session_id: Optional[str] = None,
                           trace_id: Optional[str] = None,
                           span_id: Optional[str] = None,
                           parent_span_id: Optional[str] = None,
                           user_id: Optional[str] = None,
                           chatbot_name: Optional[str] = None,
                           action: Optional[str] = None,
                           tags: Optional[List[str]] = None,
                           custom_property: Optional[Dict[str, Any]] = None,
                           target_application: Optional[str] = None) -> mcp.types.CallToolResult:
        """
        调用工具（MCP原始接口）
        
        注意：此方法不记录日志，因为 FastMCP 的 call_tool 内部会调用 call_tool_mcp，
        为避免重复记录，只在 call_tool 中记录日志。
        
        如果需要日志记录，请使用 call_tool 方法。
        
        Args:
            name: 工具名称
            arguments: 工具参数
            progress_handler: 进度处理器
            timeout: 超时时间
            其他参数: 追踪参数（会被添加到 arguments 中发送给服务端）
            
        Returns:
            mcp.types.CallToolResult: MCP原始调用结果
        """
        # 将追踪信息添加到 arguments 中发送给服务端
        enhanced_arguments = arguments.copy()
        
        # 使用提供的追踪信息或当前上下文
        current_session_id = session_id or self._current_session_id
        current_trace_id = trace_id or self._current_trace_id
        current_user_id = user_id or self._current_user_id
        
        # 如果有上下文信息，添加到参数中
        if current_session_id or current_trace_id or self._current_session_id or self._current_trace_id:
            if not current_session_id or not current_trace_id:
                self._ensure_trace_context()
                current_session_id = current_session_id or self._current_session_id
                current_trace_id = current_trace_id or self._current_trace_id
            
            span_id = str(uuid.uuid4())
            
            trace_params = {
                'session_id': current_session_id,
                'trace_id': current_trace_id,
                'span_id': span_id,
                'source_application': self.application_name
            }
            
            if current_user_id:
                trace_params['user_id'] = current_user_id
            
            # 只有当原参数中没有这些键时才添加，避免覆盖用户的参数
            for key, value in trace_params.items():
                if key not in enhanced_arguments:
                    enhanced_arguments[key] = value
        
        # 直接调用父类方法（不记录日志）
        return await super().call_tool_mcp(
            name=name,
            arguments=enhanced_arguments,
            progress_handler=progress_handler,
            timeout=timeout
        )
    
    def get_trace_headers(self) -> Dict[str, str]:
        """
        获取当前追踪上下文的头部信息，用于传播追踪信息
        
        Returns:
            Dict[str, str]: 包含追踪信息的头部字典
        """
        self._ensure_trace_context()
        
        return self.agent_watch.get_trace_headers(
            session_id=self._current_session_id,
            trace_id=self._current_trace_id,
            span_id=str(uuid.uuid4())
        )
    
    async def __aenter__(self):
        """异步上下文管理器入口"""
        result = await super().__aenter__()
        # 如果没有设置追踪上下文，则自动初始化
        if not self._current_session_id or not self._current_trace_id:
            self._ensure_trace_context()
        return result
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        return await super().__aexit__(exc_type, exc_val, exc_tb)
    
    def _prepare_input_data(
        self, 
        arguments: dict,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        准备输入数据，支持字段映射到 input.question, input.prompt, input.document
        
        Args:
            arguments: 工具调用参数
            question_field: 映射到 input.question 的参数名
            prompt_field: 映射到 input.prompt 的参数名 
            document_field: 映射到 input.document 的参数名
            
        Returns:
            格式化的输入数据字典
        """
        try:
            # 如果没有指定任何字段映射，使用默认行为
            if not question_field and not prompt_field and not document_field:
                # 默认行为：将所有参数转换为 JSON 字符串，放到 input.question 字段
                import json
                try:
                    question_value = json.dumps(arguments, ensure_ascii=False, default=str)
                except Exception:
                    question_value = str(arguments)
                
                return {
                    "question": question_value
                }
            
            # 使用字段映射
            input_data = {}
            
            # 映射 question 字段
            if question_field and question_field in arguments:
                input_data["question"] = str(arguments[question_field])
            
            # 映射 prompt 字段
            if prompt_field and prompt_field in arguments:
                input_data["prompt"] = str(arguments[prompt_field])
            
            # 映射 document 字段
            if document_field and document_field in arguments:
                input_data["document"] = str(arguments[document_field])
            
            # 如果指定了字段映射但都没有找到对应的参数，回退到默认行为
            if not input_data:
                import json
                try:
                    question_value = json.dumps(arguments, ensure_ascii=False, default=str)
                except Exception:
                    question_value = str(arguments)
                
                input_data["question"] = question_value
            
            return input_data
            
        except Exception as e:
            print(f"Failed to capture input data: {e}")
            # 如果处理失败，使用简化的参数记录
            import json
            try:
                question_value = json.dumps(arguments, ensure_ascii=False, default=str)
            except Exception:
                question_value = str(arguments)
            
            return {"question": question_value}
    
    def _prepare_output_data(
        self, 
        result: Any, 
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> tuple[str, Optional[datetime]]:
        """
        准备输出数据，支持字段映射到 output 和 first_token_timestamp
        
        Args:
            result: 函数返回结果
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
            
        Returns:
            元组：(output_data, first_token_timestamp)
        """
        import json
        
        output_data = None
        first_token_timestamp = None
        
        try:
            if result is not None:
                # 如果指定了字段映射
                if output_field or ft_field:
                    # 处理字典类型结果
                    if isinstance(result, dict):
                        if output_field and output_field in result:
                            field_value = result[output_field]
                            # 对于字符串类型，直接返回原始值
                            if isinstance(field_value, str):
                                output_data = field_value
                            else:
                                # 对于其他类型，使用 JSON 格式
                                try:
                                    output_data = json.dumps(field_value, ensure_ascii=False, default=str)
                                except Exception:
                                    output_data = str(field_value)
                        
                        if ft_field and ft_field in result:
                            ft_value = result[ft_field]
                            # 尝试解析时间戳
                            if isinstance(ft_value, datetime):
                                first_token_timestamp = ft_value
                            elif isinstance(ft_value, (int, float)):
                                first_token_timestamp = datetime.fromtimestamp(ft_value, timezone.utc)
                            elif isinstance(ft_value, str):
                                try:
                                    # 尝试解析ISO格式时间字符串
                                    first_token_timestamp = datetime.fromisoformat(ft_value.replace('Z', '+00:00'))
                                except ValueError:
                                    try:
                                        # 尝试解析时间戳字符串
                                        first_token_timestamp = datetime.fromtimestamp(float(ft_value), timezone.utc)
                                    except ValueError:
                                        pass
                    # 处理列表类型结果（fastmcp 可能返回 content 列表）
                    elif isinstance(result, list) and result:
                        # 对于列表，我们处理第一个元素
                        first_item = result[0]
                        if hasattr(first_item, '__dict__'):
                            # 如果是对象，转换为字典
                            item_dict = first_item.__dict__
                            if output_field and output_field in item_dict:
                                field_value = item_dict[output_field]
                                if isinstance(field_value, str):
                                    output_data = field_value
                                else:
                                    try:
                                        output_data = json.dumps(field_value, ensure_ascii=False, default=str)
                                    except Exception:
                                        output_data = str(field_value)
                            
                            if ft_field and ft_field in item_dict:
                                ft_value = item_dict[ft_field]
                                if isinstance(ft_value, datetime):
                                    first_token_timestamp = ft_value
                                elif isinstance(ft_value, (int, float)):
                                    first_token_timestamp = datetime.fromtimestamp(ft_value, timezone.utc)
                                elif isinstance(ft_value, str):
                                    try:
                                        first_token_timestamp = datetime.fromisoformat(ft_value.replace('Z', '+00:00'))
                                    except ValueError:
                                        try:
                                            first_token_timestamp = datetime.fromtimestamp(float(ft_value), timezone.utc)
                                        except ValueError:
                                            pass
                
                # 如果没有通过字段映射获取到输出数据，使用默认行为
                if output_data is None:
                    # 对于字符串类型，直接返回原始值
                    if isinstance(result, str):
                        output_data = result
                    elif isinstance(result, list):
                        # 对于列表类型（fastmcp content），提取文本内容
                        text_parts = []
                        for item in result:
                            if hasattr(item, 'text'):
                                text_parts.append(item.text)
                            else:
                                text_parts.append(str(item))
                        output_data = '\n'.join(text_parts) if text_parts else str(result)
                    else:
                        # 对于其他类型，使用 JSON 格式
                        try:
                            output_data = json.dumps(result, ensure_ascii=False, default=str)
                        except Exception:
                            output_data = str(result)
                    
        except Exception:
            output_data = f"<{type(result).__name__} object>"
        
        return output_data, first_token_timestamp


# 提供便捷的别名
Client = AgentWatchFastMCPClient
