"""
Agent Watch SDK装饰器模块

扩展FastMCP装饰器功能，提供便捷的日志记录功能，
自动处理工具调用的日志追踪和错误监控。
"""

import functools
import uuid
import inspect
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional, TypeVar, Union, List

from .client import AgentWatchClient
from .models import LogStage, LogEntry

F = TypeVar('F', bound=Callable[..., Any])


class AgentWatchMCPDecorator:
    """Agent Watch MCP 装饰器类，用于扩展 FastMCP 工具"""
    
    def __init__(self, client: AgentWatchClient):
        """
        初始化装饰器
        
        Args:
            client: AgentWatchClient 实例
        """
        self.client = client
    
    def logged_tool(
        self,
        *,
        name: Optional[str] = None,
        title: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        output_schema: Optional[Dict[str, Any]] = None,
        annotations: Optional[Dict[str, Any]] = None,
        exclude_args: Optional[List[str]] = None,
        enabled: Optional[bool] = None,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        custom_tags: Optional[List[str]] = None,
        output_type: str = "non-stream",
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None,
    ) -> Callable[[F], F]:
        """
        带日志记录的工具装饰器
        
        这个装饰器扩展了 FastMCP 的 @tool 装饰器，添加了自动的日志记录功能。
        它会自动记录工具的调用、响应和错误信息到 Agent Watch 系统。
        
        Args:
            name: 工具名称
            title: 工具标题
            description: 工具描述
            tags: 工具标签
            output_schema: 输出模式
            annotations: 注解
            exclude_args: 排除的参数
            enabled: 是否启用
            log_input: 是否记录输入
            log_output: 是否记录输出
            log_errors: 是否记录错误
            custom_tags: 用户自定义标签
            output_type: 输出类型 (stream/non-stream)
            question_field: 指定映射到 input.question 的参数名，如 "user_query"
            prompt_field: 指定映射到 input.prompt 的参数名，如 "system_prompt"
            document_field: 指定映射到 input.document 的参数名，如 "context_docs"
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
        
        Returns:
            装饰后的函数
            
        Example:
            ```python
            # 初始化 client 和装饰器
            client = AgentWatchClient(...)
            aw = AgentWatchMCPDecorator(client)
            
            # 使用装饰器
            @aw.logged_tool(
                name="calculate",
                description="执行数学计算",
                question_field="user_input",
                prompt_field="system_prompt",
                output_field="result",
                ft_field="first_token_time"
            )
            def calculate(
                user_input: str, 
                system_prompt: str, 
                x: int, 
                y: int,
                source_application: str = None  # 动态传入
            ) -> dict:
                return {"result": x + y, "first_token_time": datetime.now()}
            ```
        """
        def decorator(func: F) -> F:
            # 获取原始函数的签名
            orig_sig = inspect.signature(func)
            
            # 添加我们需要的追踪参数到签名
            # 注意：只有当原函数签名中不存在这些参数时才添加
            params = list(orig_sig.parameters.values())
            param_names = set(p.name for p in params)
            
            # 要添加的参数列表
            trace_params = {
                'session_id': inspect.Parameter(
                    'session_id', inspect.Parameter.KEYWORD_ONLY,
                    default=None, annotation=Optional[str]
                ),
                'trace_id': inspect.Parameter(
                    'trace_id', inspect.Parameter.KEYWORD_ONLY,
                    default=None, annotation=Optional[str]
                ),
                'span_id': inspect.Parameter(
                    'span_id', inspect.Parameter.KEYWORD_ONLY,
                    default=None, annotation=Optional[str]
                ),
                'parent_span_id': inspect.Parameter(
                    'parent_span_id', inspect.Parameter.KEYWORD_ONLY,
                    default=None, annotation=Optional[str]
                ),
                'source_application': inspect.Parameter(
                    'source_application', inspect.Parameter.KEYWORD_ONLY,
                    default=None, annotation=Optional[str]
                ),
                'user_id': inspect.Parameter(
                    'user_id', inspect.Parameter.KEYWORD_ONLY,
                    default=None, annotation=Optional[str]
                ),
                'chatbot_name': inspect.Parameter(
                    'chatbot_name', inspect.Parameter.KEYWORD_ONLY,
                    default=None, annotation=Optional[str]
                ),
                'custom_property': inspect.Parameter(
                    'custom_property', inspect.Parameter.KEYWORD_ONLY,
                    default=None, annotation=Optional[Dict[str, Any]]
                )
            }
            
            # 添加不存在的参数
            for param_name, param in trace_params.items():
                if param_name not in param_names:
                    params.append(param)
            
            # 创建新签名
            new_sig = orig_sig.replace(parameters=params)
            
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await self._execute_with_logging(
                    func, args, kwargs,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    custom_tags=custom_tags,
                    output_type=output_type,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                return self._execute_sync_with_logging(
                    func, args, kwargs,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    custom_tags=custom_tags,
                    output_type=output_type,
                    question_field=question_field,
                    prompt_field=prompt_field,
                    document_field=document_field,
                    output_field=output_field,
                    ft_field=ft_field
                )
            
            # 根据函数是否为协程选择包装器
            wrapper = async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper
            
            # 应用新签名到包装函数
            wrapper.__signature__ = new_sig
            
            # 手动设置 __annotations__ 属性，确保类型系统能够正确解析
            if hasattr(func, '__annotations__'):
                new_annotations = func.__annotations__.copy()
            else:
                new_annotations = {}
            
            # 添加我们的追踪参数的类型注解
            trace_annotations = {
                'session_id': Optional[str],
                'trace_id': Optional[str], 
                'span_id': Optional[str],
                'parent_span_id': Optional[str],
                'source_application': Optional[str],
                'user_id': Optional[str],
                'chatbot_name': Optional[str],
                'custom_property': Optional[Dict[str, Any]]
            }
            
            for param_name, annotation in trace_annotations.items():
                if param_name not in new_annotations:
                    new_annotations[param_name] = annotation
            
            wrapper.__annotations__ = new_annotations
            
            return wrapper
        
        return decorator
    
    async def _execute_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        custom_tags: Optional[List[str]] = None,
        output_type: str = "non-stream",
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """
        执行函数并记录日志 (server端视角)
        
        Args:
            func: 要执行的函数
            args: 位置参数
            kwargs: 关键字参数
            log_input: 是否记录输入
            log_output: 是否记录输出
            log_errors: 是否记录错误
            custom_tags: 用户自定义标签
            output_type: 输出类型 (stream/non-stream)
        
        Returns:
            函数执行结果
        """
        # 如果不需要任何日志记录，直接执行函数
        if not log_input and not log_output and not log_errors:
            # 先过滤掉追踪参数
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'user_id', 'chatbot_name', 'custom_property'
            }
            filtered_kwargs = {
                k: v for k, v in kwargs.items() 
                if k not in trace_param_names
            }
            
            if inspect.iscoroutinefunction(func):
                return await func(*args, **filtered_kwargs)
            else:
                return func(*args, **filtered_kwargs)
        
        # 尝试从上下文或参数中获取追踪信息
        session_id = kwargs.get('session_id', str(uuid.uuid4()))
        trace_id = kwargs.get('trace_id', self.client.generate_trace_id())
        span_id = kwargs.get('span_id', self.client.generate_span_id())
        parent_span_id = kwargs.get('parent_span_id')
        
        func_name = func.__name__
        # 从kwargs中动态获取source_application
        source_app = kwargs.get('source_application', 'client')
        
        # 准备标签
        all_tags = ["fastmcp-tool", "agent-watch"]
        if custom_tags:
            all_tags.extend(custom_tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            # 先过滤掉追踪参数，只使用原始函数需要的参数
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'user_id', 'chatbot_name', 'custom_property'
            }
            
            filtered_kwargs = {
                k: v for k, v in kwargs.items() 
                if k not in trace_param_names
            }
            
            # 使用字段映射功能准备输入数据
            input_data = self._prepare_input_data(
                func, args, filtered_kwargs,
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 记录接收请求 (server端接收客户端请求)
        start_time = datetime.now(timezone.utc)
        if log_input:
            self.client.receive_request(
                session_id=session_id,
                trace_id=trace_id,
                span_id=span_id,
                parent_span_id=parent_span_id,
                source_application=source_app,
                input_data=input_data,
                user_id=kwargs.get('user_id'),
                chatbot_name=kwargs.get('chatbot_name'),
                action=func_name,
                tags=all_tags,
                custom_property=kwargs.get('custom_property')
            )
        
        try:
            # 准备传递给原始函数的参数
            # 移除我们添加的追踪参数，只传递原始函数需要的参数
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'user_id', 'chatbot_name', 'custom_property'
            }
            
            # 过滤掉追踪参数
            filtered_kwargs = {
                k: v for k, v in kwargs.items() 
                if k not in trace_param_names
            }
            
            # 执行函数
            if inspect.iscoroutinefunction(func):
                result = await func(*args, **filtered_kwargs)
            else:
                result = func(*args, **filtered_kwargs)
            
            # 记录发送响应 (server端发送响应给客户端)
            if log_output:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                self.client.send_response(
                    session_id=session_id,
                    trace_id=trace_id,
                    span_id=span_id,
                    parent_span_id=parent_span_id,
                    status_code=200,
                    target_application=source_app,  # 响应发送给调用方
                    output=output_data,
                    output_type=output_type,
                    user_id=kwargs.get('user_id'),
                    chatbot_name=kwargs.get('chatbot_name'),
                    action=func_name,
                    tags=all_tags,
                    custom_property=kwargs.get('custom_property'),
                    first_token_timestamp=first_token_timestamp
                )
            
            return result
            
        except Exception as e:
            # 记录错误响应
            if log_errors:
                error_detail = f"{type(e).__name__}: {str(e)}"
                error_tags = all_tags + ["error"]
                
                self.client.send_response(
                    session_id=session_id,
                    trace_id=trace_id,
                    span_id=span_id,
                    parent_span_id=parent_span_id,
                    status_code=500,
                    target_application=source_app,  # 错误响应发送给调用方
                    output=error_detail,
                    output_type=output_type,
                    user_id=kwargs.get('user_id'),
                    chatbot_name=kwargs.get('chatbot_name'),
                    action=func_name,
                    tags=error_tags,
                    custom_property=kwargs.get('custom_property')
                )
            
            # 重新抛出异常
            raise

    
    def _execute_sync_with_logging(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        log_input: bool = True,
        log_output: bool = True,
        log_errors: bool = True,
        custom_tags: Optional[List[str]] = None,
        output_type: str = "non-stream",
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None,
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> Any:
        """
        同步执行函数并记录日志 (server端视角)
        
        Args:
            func: 要执行的函数
            args: 位置参数
            kwargs: 关键字参数
            log_input: 是否记录输入
            log_output: 是否记录输出
            log_errors: 是否记录错误
            custom_tags: 用户自定义标签
            output_type: 输出类型 (stream/non-stream)
        
        Returns:
            函数执行结果
        """
        # 如果不需要任何日志记录，直接执行函数
        if not log_input and not log_output and not log_errors:
            # 先过滤掉追踪参数
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'user_id', 'chatbot_name', 'custom_property'
            }
            filtered_kwargs = {
                k: v for k, v in kwargs.items() 
                if k not in trace_param_names
            }
            return func(*args, **filtered_kwargs)
        
        # 尝试从上下文或参数中获取追踪信息
        session_id = kwargs.get('session_id', str(uuid.uuid4()))
        trace_id = kwargs.get('trace_id', self.client.generate_trace_id())
        span_id = kwargs.get('span_id', self.client.generate_span_id())
        parent_span_id = kwargs.get('parent_span_id')
        
        func_name = func.__name__
        # 从kwargs中动态获取source_application
        source_app = kwargs.get('source_application', 'client')
        
        # 准备标签
        all_tags = ["fastmcp-tool", "agent-watch"]
        if custom_tags:
            all_tags.extend(custom_tags)
        
        # 准备输入数据
        input_data = None
        if log_input:
            # 先过滤掉追踪参数，只使用原始函数需要的参数
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'user_id', 'chatbot_name', 'custom_property'
            }
            
            filtered_kwargs = {
                k: v for k, v in kwargs.items() 
                if k not in trace_param_names
            }
            
            # 使用字段映射功能准备输入数据
            input_data = self._prepare_input_data(
                func, args, filtered_kwargs,
                question_field=question_field,
                prompt_field=prompt_field,
                document_field=document_field
            )
        
        # 记录接收请求 (server端接收客户端请求)
        start_time = datetime.now(timezone.utc)
        if log_input:
            self.client.receive_request(
                session_id=session_id,
                trace_id=trace_id,
                span_id=span_id,
                parent_span_id=parent_span_id,
                source_application=source_app,
                input_data=input_data,
                user_id=kwargs.get('user_id'),
                chatbot_name=kwargs.get('chatbot_name'),
                action=func_name,
                tags=all_tags,
                custom_property=kwargs.get('custom_property')
            )
        
        try:
            # 准备传递给原始函数的参数
            # 检查原始函数参数，如果有追踪参数就不过滤对应的参数
            orig_param_names = set(inspect.signature(func).parameters.keys())
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'user_id', 'chatbot_name', 'custom_property'
            }
            # 只过滤掉原函数没有的追踪参数
            filtered_kwargs = {
                k: v for k, v in kwargs.items()
                if (k not in trace_param_names) or (k in orig_param_names)
            }
            
            # 执行函数（同步）
            result = func(*args, **filtered_kwargs)
            
            # 记录发送响应 (server端发送响应给客户端)
            if log_output:
                output_data, first_token_timestamp = self._prepare_output_data(
                    result, output_field=output_field, ft_field=ft_field
                )
                
                self.client.send_response(
                    session_id=session_id,
                    trace_id=trace_id,
                    span_id=span_id,
                    parent_span_id=parent_span_id,
                    status_code=200,
                    target_application=source_app,  # 响应发送给调用方
                    output=output_data,
                    output_type=output_type,
                    user_id=kwargs.get('user_id'),
                    chatbot_name=kwargs.get('chatbot_name'),
                    action=func_name,
                    tags=all_tags,
                    custom_property=kwargs.get('custom_property'),
                    first_token_timestamp=first_token_timestamp
                )
            
            return result
            
        except Exception as e:
            # 记录错误响应
            if log_errors:
                error_detail = f"{type(e).__name__}: {str(e)}"
                error_tags = all_tags + ["error"]
                
                self.client.send_response(
                    session_id=session_id,
                    trace_id=trace_id,
                    span_id=span_id,
                    parent_span_id=parent_span_id,
                    status_code=500,
                    target_application=source_app,  # 错误响应发送给调用方
                    output=error_detail,
                    output_type=output_type,
                    user_id=kwargs.get('user_id'),
                    chatbot_name=kwargs.get('chatbot_name'),
                    action=func_name,
                    tags=error_tags,
                    custom_property=kwargs.get('custom_property')
                )
            
            # 重新抛出异常
            raise

    def _prepare_input_data(
        self, 
        func: Callable, 
        args: tuple, 
        kwargs: dict,
        question_field: Optional[str] = None,
        prompt_field: Optional[str] = None,
        document_field: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        准备输入数据，支持字段映射到 input.question, input.prompt, input.document
        
        Args:
            func: 被装饰的函数
            args: 位置参数
            kwargs: 关键字参数
            question_field: 映射到 input.question 的参数名
            prompt_field: 映射到 input.prompt 的参数名 
            document_field: 映射到 input.document 的参数名
            
        Returns:
            格式化的输入数据字典
        """
        try:
            # 获取函数签名
            signature = inspect.signature(func)
            
            # 先过滤掉追踪参数，只使用原始函数需要的参数
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'user_id', 'chatbot_name', 'custom_property'
            }
            
            filtered_kwargs = {
                k: v for k, v in kwargs.items() 
                if k not in trace_param_names
            }
            
            # 绑定所有参数
            bound_args = signature.bind(*args, **filtered_kwargs)
            bound_args.apply_defaults()
            
            all_arguments = dict(bound_args.arguments)
            
            # 如果没有指定任何字段映射，使用默认行为
            if not question_field and not prompt_field and not document_field:
                # 默认行为：将所有参数转换为 JSON 字符串，放到 input.question 字段
                import json
                try:
                    question_value = json.dumps(all_arguments, ensure_ascii=False, default=str)
                except Exception:
                    question_value = str(all_arguments)
                
                return {
                    "question": question_value
                }
            
            # 使用字段映射
            input_data = {}
            
            # 映射 question 字段
            if question_field and question_field in all_arguments:
                input_data["question"] = str(all_arguments[question_field])
            
            # 映射 prompt 字段
            if prompt_field and prompt_field in all_arguments:
                input_data["prompt"] = str(all_arguments[prompt_field])
            
            # 映射 document 字段
            if document_field and document_field in all_arguments:
                input_data["document"] = str(all_arguments[document_field])
            
            # 如果指定了字段映射但都没有找到对应的参数，回退到默认行为
            if not input_data:
                import json
                try:
                    question_value = json.dumps(all_arguments, ensure_ascii=False, default=str)
                except Exception:
                    question_value = str(all_arguments)
                
                input_data["question"] = question_value
            
            return input_data
            
        except Exception as e:
            print(f"Failed to capture input data: {e}")
            # 如果处理失败，使用简化的参数记录
            trace_param_names = {
                'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                'user_id', 'chatbot_name', 'custom_property'
            }
            filtered_kwargs = {
                k: v for k, v in kwargs.items() 
                if k not in trace_param_names
            }
            import json
            try:
                question_value = json.dumps({
                    "args_count": len(args), 
                    "kwargs": filtered_kwargs
                }, ensure_ascii=False, default=str)
            except Exception:
                question_value = f"args_count: {len(args)}, kwargs: {filtered_kwargs}"
            
            return {"question": question_value}

    def _prepare_output_data(
        self, 
        result: Any, 
        output_field: Optional[str] = None,
        ft_field: Optional[str] = None
    ) -> tuple[str, Optional[datetime]]:
        """
        准备输出数据，支持字段映射到 output 和 first_token_timestamp
        
        Args:
            result: 函数返回结果
            output_field: 指定映射到 output 的字段名，当结果为字典或数组时使用
            ft_field: 指定映射到 first_token_timestamp 的字段名，当结果为字典或数组时使用
            
        Returns:
            元组：(output_data, first_token_timestamp)
        """
        import json
        from datetime import datetime, timezone
        
        output_data = None
        first_token_timestamp = None
        
        try:
            if result is not None:
                # 如果指定了字段映射
                if output_field or ft_field:
                    # 处理字典类型结果
                    if isinstance(result, dict):
                        if output_field and output_field in result:
                            field_value = result[output_field]
                            # 对于字符串类型，直接返回原始值
                            if isinstance(field_value, str):
                                output_data = field_value
                            else:
                                # 对于其他类型，使用 JSON 格式
                                try:
                                    output_data = json.dumps(field_value, ensure_ascii=False, default=str)
                                except Exception:
                                    output_data = str(field_value)
                        
                        if ft_field and ft_field in result:
                            ft_value = result[ft_field]
                            # 尝试解析时间戳
                            if isinstance(ft_value, datetime):
                                first_token_timestamp = ft_value
                            elif isinstance(ft_value, (int, float)):
                                first_token_timestamp = datetime.fromtimestamp(ft_value, timezone.utc)
                            elif isinstance(ft_value, str):
                                try:
                                    # 尝试解析ISO格式时间字符串
                                    first_token_timestamp = datetime.fromisoformat(ft_value.replace('Z', '+00:00'))
                                except ValueError:
                                    try:
                                        # 尝试解析时间戳字符串
                                        first_token_timestamp = datetime.fromtimestamp(float(ft_value), timezone.utc)
                                    except ValueError:
                                        pass
                
                # 如果没有通过字段映射获取到输出数据，使用默认行为（JSON格式，不限制长度）
                if output_data is None:
                    # 对于字符串类型，直接返回原始值
                    if isinstance(result, str):
                        output_data = result
                    else:
                        # 对于其他类型，使用 JSON 格式
                        try:
                            output_data = json.dumps(result, ensure_ascii=False, default=str)
                        except Exception:
                            output_data = str(result)
                    
        except Exception:
            output_data = f"<{type(result).__name__} object>"
        
        return output_data, first_token_timestamp

    def fastmcp_integration(self, fastmcp_server):
        """
        集成到 FastMCP 服务器的辅助方法
        
        这个方法可以将 Agent Watch 装饰器功能集成到现有的 FastMCP 服务器中，
        使你可以直接在服务器实例上使用 logged_tool 装饰器。
        
        Args:
            fastmcp_server: FastMCP 服务器实例
            
        Example:
            ```python
            from fastmcp import FastMCP
            from agent_watch_sdk import AgentWatchClient, AgentWatchMCPDecorator
            
            # 创建服务器和客户端
            server = FastMCP()
            client = AgentWatchClient(...)
            aw = AgentWatchMCPDecorator(client)
            
            # 集成到服务器
            aw.fastmcp_integration(server)
            
            # 现在可以使用服务器的 logged_tool 方法
            @server.logged_tool(name="my_tool")
            def my_tool():
                return "Hello World"
            ```
        """
        # 保存原始的 tool 方法
        original_tool = fastmcp_server.tool
        
        # 创建集成的 logged_tool 方法
        def logged_tool_wrapper(
            name_or_fn=None,
            *,
            name: Optional[str] = None,
            title: Optional[str] = None,
            description: Optional[str] = None,
            tags: Optional[List[str]] = None,
            output_schema: Optional[Dict[str, Any]] = None,
            annotations: Optional[Dict[str, Any]] = None,
            exclude_args: Optional[List[str]] = None,
            enabled: Optional[bool] = None,
            log_input: bool = True,
            log_output: bool = True,
            log_errors: bool = True,
            custom_tags: Optional[List[str]] = None,
            output_type: str = "non-stream",
            expose_trace_params: bool = False,
            question_field: Optional[str] = None,
            prompt_field: Optional[str] = None,
            document_field: Optional[str] = None,
            output_field: Optional[str] = None,
            ft_field: Optional[str] = None,
        ):
            """集成的 logged_tool 装饰器，同时注册到 FastMCP 和 Agent Watch
            
            Args:
                expose_trace_params: 是否向 FastMCP 暴露追踪参数（session_id, trace_id等）
                                   True: FastMCP 工具签名中包含追踪参数
                                   False: 追踪参数从 FastMCP 工具签名中排除（默认）
            """
            
            def decorator(func):
                # 获取原始函数的签名
                orig_sig = inspect.signature(func)
                
                # 添加我们需要的追踪参数到签名
                # 注意：只有当原函数签名中不存在这些参数时才添加
                params = list(orig_sig.parameters.values())
                param_names = set(p.name for p in params)
                
                # 要添加的参数列表
                trace_params = {
                    'session_id': inspect.Parameter(
                        'session_id', inspect.Parameter.KEYWORD_ONLY,
                        default=None, annotation=Optional[str]
                    ),
                    'trace_id': inspect.Parameter(
                        'trace_id', inspect.Parameter.KEYWORD_ONLY,
                        default=None, annotation=Optional[str]
                    ),
                    'span_id': inspect.Parameter(
                        'span_id', inspect.Parameter.KEYWORD_ONLY,
                        default=None, annotation=Optional[str]
                    ),
                    'parent_span_id': inspect.Parameter(
                        'parent_span_id', inspect.Parameter.KEYWORD_ONLY,
                        default=None, annotation=Optional[str]
                    ),
                    'source_application': inspect.Parameter(
                        'source_application', inspect.Parameter.KEYWORD_ONLY,
                        default=None, annotation=Optional[str]
                    ),
                    'user_id': inspect.Parameter(
                        'user_id', inspect.Parameter.KEYWORD_ONLY,
                        default=None, annotation=Optional[str]
                    ),
                    'custom_property': inspect.Parameter(
                        'custom_property', inspect.Parameter.KEYWORD_ONLY,
                        default=None, annotation=Optional[Dict[str, Any]]
                    )
                }
                
                # 添加不存在的参数
                for param_name, param in trace_params.items():
                    if param_name not in param_names:
                        params.append(param)
                
                # 创建新签名
                new_sig = orig_sig.replace(parameters=params)
                
                # 首先应用 Agent Watch 日志装饰器
                logged_func = self.logged_tool(
                    name=name,
                    title=title,
                    description=description,
                    tags=tags,
                    output_schema=output_schema,
                    annotations=annotations,
                    exclude_args=exclude_args,
                    enabled=enabled,
                    log_input=log_input,
                    log_output=log_output,
                    log_errors=log_errors,
                    custom_tags=custom_tags,
                    output_type=output_type,
                )(func)
                
                # 确保我们的新签名被保留，并且类型提示正确
                logged_func.__signature__ = new_sig
                
                # 手动设置 __annotations__ 属性，确保 Pydantic 能够正确解析
                if hasattr(func, '__annotations__'):
                    new_annotations = func.__annotations__.copy()
                else:
                    new_annotations = {}
                
                # 添加我们的追踪参数的类型注解
                trace_annotations = {
                    'session_id': Optional[str],
                    'trace_id': Optional[str], 
                    'span_id': Optional[str],
                    'parent_span_id': Optional[str],
                    'source_application': Optional[str],
                    'user_id': Optional[str],
                    'custom_property': Optional[Dict[str, Any]]
                }
                
                for param_name, annotation in trace_annotations.items():
                    if param_name not in new_annotations:
                        new_annotations[param_name] = annotation
                
                logged_func.__annotations__ = new_annotations
                
                # 构建传递给 FastMCP 的参数，根据 expose_trace_params 决定是否排除追踪参数
                if expose_trace_params:
                    # 暴露追踪参数给 FastMCP，使用原有的 exclude_args
                    final_exclude_args = exclude_args or []
                else:
                    # 不暴露追踪参数给 FastMCP，将追踪参数添加到 exclude_args
                    exclude_trace_args = [
                        'session_id', 'trace_id', 'span_id', 'parent_span_id', 'source_application',
                        'user_id', 'custom_property'
                    ]
                    # 合并现有的 exclude_args 和我们的追踪参数
                    final_exclude_args = (exclude_args or []) + exclude_trace_args
                
                # 然后注册到 FastMCP（只传递FastMCP支持的参数）
                fastmcp_kwargs = {}
                if name is not None:
                    fastmcp_kwargs['name'] = name
                if description is not None:
                    fastmcp_kwargs['description'] = description
                if tags is not None:
                    fastmcp_kwargs['tags'] = set(tags)
                if output_schema is not None:
                    fastmcp_kwargs['output_schema'] = output_schema
                if annotations is not None:
                    fastmcp_kwargs['annotations'] = annotations
                # 使用合并后的 exclude_args
                fastmcp_kwargs['exclude_args'] = final_exclude_args
                if enabled is not None:
                    fastmcp_kwargs['enabled'] = enabled
                
                # 生成最终工具
                tool = original_tool(logged_func, **fastmcp_kwargs)
                
                return tool
            
            # 处理不同的调用模式
            if name_or_fn is not None and callable(name_or_fn):
                # 直接传入函数的情况：@server.logged_tool
                return decorator(name_or_fn)
            else:
                # 带参数的情况：@server.logged_tool(name="...")
                return decorator
        
        # 为 FastMCP 服务器添加 logged_tool 方法
        fastmcp_server.logged_tool = logged_tool_wrapper
        
        # 添加获取客户端的方法
        fastmcp_server.agent_watch_client = self.client
        
        return fastmcp_server


def create_agent_watch_mcp_decorator(
    collector_url: str,
    application_name: str,
    **auth_kwargs
) -> AgentWatchMCPDecorator:
    """
    便捷函数：创建 Agent Watch 装饰器
    
    Args:
        collector_url: Agent Watch Collector URL
        application_name: 应用名称
        **auth_kwargs: 认证参数
    
    Returns:
        AgentWatchMCPDecorator 实例
        
    Example:
        ```python
        # 创建装饰器
        aw = create_agent_watch_mcp_decorator(
            collector_url="https://collector.example.com",
            application_name="myApp",
            auth_type="fixed_token"
        )
        
        # 使用装饰器 (chatbot_name 现在作为工具参数传递)
        @aw.logged_tool()
        def my_function(chatbot_name: str = "myBot"):
            # chatbot_name 现在是函数参数，而不是装饰器参数
            return "result"
        ```
    """
    client = AgentWatchClient(
        collector_url=collector_url,
        application_name=application_name,
        **auth_kwargs
    )
    return AgentWatchMCPDecorator(client)


# 便捷的全局实例创建函数
_global_decorator: Optional[AgentWatchMCPDecorator] = None

def setup_global_decorator(
    collector_url: str,
    application_name: str,
    **auth_kwargs
) -> AgentWatchMCPDecorator:
    """
    设置全局 Agent Watch 装饰器实例
    
    设置后可以直接使用 logged_tool 装饰器，无需每次创建实例。
    
    Args:
        collector_url: Agent Watch Collector URL
        application_name: 应用名称
        **auth_kwargs: 认证参数
    
    Returns:
        AgentWatchMCPDecorator 实例
        
    Example:
        ```python
        from agent_watch_sdk.fastmcp_decorator import setup_global_decorator, logged_tool
        
        # 设置全局装饰器
        setup_global_decorator(
            collector_url="https://collector.example.com",
            application_name="myApp"
        )
        
        # 直接使用装饰器 (chatbot_name 现在作为工具参数传递)
        @logged_tool(name="my_tool")
        def my_function(chatbot_name: str = "myBot"):
            # chatbot_name 现在是函数参数，而不是装饰器参数
            return "result"
        ```
    """
    global _global_decorator
    _global_decorator = create_agent_watch_mcp_decorator(
        collector_url=collector_url,
        application_name=application_name,
        **auth_kwargs
    )
    return _global_decorator


def logged_tool(
    *,
    name: Optional[str] = None,
    title: Optional[str] = None,
    description: Optional[str] = None,
    tags: Optional[List[str]] = None,
    output_schema: Optional[Dict[str, Any]] = None,
    annotations: Optional[Dict[str, Any]] = None,
    exclude_args: Optional[List[str]] = None,
    enabled: Optional[bool] = None,
    log_input: bool = True,
    log_output: bool = True,
    log_errors: bool = True,
    custom_tags: Optional[List[str]] = None,
    output_type: str = "non-stream",
    question_field: Optional[str] = None,
    prompt_field: Optional[str] = None,
    document_field: Optional[str] = None,
    output_field: Optional[str] = None,
    ft_field: Optional[str] = None,
) -> Callable[[F], F]:
    """
    全局 logged_tool 装饰器
    
    使用前需先调用 setup_global_decorator() 设置全局实例。
    
    Args:
        同 AgentWatchMCPDecorator.logged_tool()
    
    Returns:
        装饰后的函数
        
    Raises:
        RuntimeError: 如果未设置全局装饰器实例
    """
    if _global_decorator is None:
        raise RuntimeError(
            "Global AgentWatch decorator not initialized. "
            "Call setup_global_decorator() first."
        )
    
    return _global_decorator.logged_tool(
        name=name,
        title=title,
        description=description,
        tags=tags,
        output_schema=output_schema,
        annotations=annotations,
        exclude_args=exclude_args,
        enabled=enabled,
        log_input=log_input,
        log_output=log_output,
        log_errors=log_errors,
        custom_tags=custom_tags,
        output_type=output_type,
        question_field=question_field,
        prompt_field=prompt_field,
        document_field=document_field,
        output_field=output_field,
        ft_field=ft_field,
    )
