from enum import Enum
from dataclasses import dataclass
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone


class LogStage(Enum):
    RECEIVE_REQUEST = "receiveRequest"
    SEND_REQUEST = "sendRequest"
    RECEIVE_RESPONSE = "receiveResponse"
    SEND_RESPONSE = "sendResponse"


@dataclass
class LogEntry:
    session_id: str
    trace_id: str
    span_id: str
    stage: LogStage
    timestamp: datetime
    source_application: str
    target_application: str
    chatbot_name: str
    
    # Optional fields
    parent_span_id: Optional[str] = None
    user_id: Optional[str] = None
    severity_text: str = "INFO"
    action: Optional[str] = None
    input: Optional[Dict[str, Any]] = None
    send_timestamp: Optional[datetime] = None
    tags: Optional[List[str]] = None
    output_type: Optional[str] = None
    output: Optional[str] = None
    first_token_timestamp: Optional[datetime] = None
    first_token_duration: Optional[int] = None
    receive_timestamp: Optional[datetime] = None
    status: Optional[int] = None
    response_time: Optional[int] = None
    result: Optional[str] = None
    error_detail: Optional[str] = None
    custom_property: Optional[Dict[str, Any]] = None
    scenario: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        result = {
            "sessionId": self.session_id,
            "traceId": self.trace_id,
            "spanId": self.span_id,
            "stage": self.stage.value,
            "timestamp": int(self.timestamp.timestamp() * 1000),  # Unix timestamp in milliseconds
            "sourceApplication": self.source_application,
            "targetApplication": self.target_application,
            "chatbotName": self.chatbot_name,
            "severityText": self.severity_text,
        }
        
        # Add optional fields if they exist
        optional_fields = {
            "parentSpanId": self.parent_span_id,
            "userId": self.user_id,
            "action": self.action,
            "input": self.input,
            "sendTimestamp": int(self.send_timestamp.timestamp() * 1000) if self.send_timestamp else None,
            "tags": self.tags,
            "outputType": self.output_type,
            "output": self.output,
            "firstTokenTimestamp": int(self.first_token_timestamp.timestamp() * 1000) if self.first_token_timestamp else None,
            "firstTokenDuration": self.first_token_duration,
            "receiveTimestamp": int(self.receive_timestamp.timestamp() * 1000) if self.receive_timestamp else None,
            "status": self.status,
            "responseTime": self.response_time,
            "result": self.result,
            "errorDetail": self.error_detail,
            "customProperty": self.custom_property,
            "scenario": self.scenario,
        }
        
        # Only include non-None values
        for key, value in optional_fields.items():
            if value is not None:
                result[key] = value
                
        return result

